# 模块：推广分销与提现

一句话：给每个用户一条专属推广链接，好友下单后按比例把佣金打进他的余额；余额可以申请提现，管理员审核打款。

## 归属规则

| 环节 | 行为 |
|---|---|
| 生成码 | 首次访问时生成 6 位码（`23456789ABCDEFGHJKLMNPQRSTUVWXYZ`，去掉易混的 0/O/1/I），存 `allin_ref_code` |
| 传播 | 好友访问 `?ref=CODE` → 服务端写 30 天 `allin_ref` cookie（httponly / SameSite=Lax） |
| 绑定 | **仅在注册那一刻**读 cookie，写 `allin_referred_by`，之后不再改写 |
| 自查 | 不能邀请自己 |
| 闭环 | 绑定前走一遍上级链，发现成环直接拒绝（A 邀 B、B 又邀 A 会让两个账号互相刷单） |

`?ref` 只对未登录访客生效；已登录用户改 cookie 不会改归属。

## 佣金

- 比例在「设置 → Allin Pro → 推广分销」：一级默认 `0.1`（10%），二级默认 `0`（关闭），上限分别 50% 与 30%。
- 触发点是 `aurora_order_paid`，优先级 15——订单状态机仍是站点原来的那个，本模块只读不改。
- 基数是订单**实付金额**（`amount`，已扣优惠券），不是标价。
- **充值订单不产生佣金**：带 `_allin_recharge_amount` 的订单直接跳过。否则「充值 100 → 自己邀自己 → 拿 10 → 再充」就是提款机。
- 幂等键是 `订单号:层级`。支付回调重放、支付模块重试、管理员手动补单，都只会入账一次。
- 佣金进余额账户（`allin_balance_ledger`，`type = commission`），同时累加 `allin_commission_total` 供「累计佣金」展示。
- 订单上留 `_allin_commission`：谁、几级、多少钱，退款对账时能直接看到。
- 钩子：`allin_pro_referral_bound( $user_id, $referrer )`、`allin_pro_commission_paid( $order_id, $paid )`。

## 提现

**先扣钱，再建单。** 顺序反过来的话，两次并发提交可以拿到两笔「待审核」而余额只够一笔。

1. 用户提交金额 / 收款方式（微信、支付宝）/ 账号 / 姓名。
2. 服务端校验：金额 ≥ 门槛（默认 10 元，可设置）、≤ 50000、账号非空、余额足够。
3. 余额不足 → 不建单；建单后扣款失败 → 删除该单。**不存在「有单没钱」的行**。
4. 审核在后台「提现申请」列表：标记已打款，或驳回并退余额。
5. 驳回退款用 `wd_<id>` 作幂等键，重复驳回不会退两次。

打款是人工的：运营看到渠道和账号，线下转，然后在后台点「标记已打款」。**不接任何支付商接口**，没有商户资质也能用。

## 页面与接口

| 入口 | 说明 |
|---|---|
| `/invite`（页面「推广中心」，短代码 `[allin_invite]`） | 专属链接、已邀请人数、累计佣金、可提现余额、提现表单、提现记录、最近佣金 |
| 用户中心侧栏 | 主题过滤器 `aurora_user_quick_links` 注入「推广中心 · 佣金提现」 |
| `GET /wp-json/allin/v1/referral` | 需登录：`code` / `link` / `invited` / `earned` / `balance` / `rates` / `referrer` |
| 后台 → 提现申请 | 列表带用户、金额、方式+账号、状态、两个操作按钮 |

## 数据

| 位置 | 键 / 表 | 内容 |
|---|---|---|
| 用户 meta | `allin_ref_code` | 专属码 |
| 用户 meta | `allin_referred_by` / `allin_referred_at` | 归属（写一次） |
| 用户 meta | `allin_ref_count` / `allin_commission_total` | 已邀请人数、累计佣金 |
| 订单 meta | `_allin_commission` | 本单付给谁、几级、多少 |
| CPT | `allin_withdraw` | `_wd_user` `_wd_amount` `_wd_channel` `_wd_account` `_wd_name` `_wd_status` `_wd_ref` |

`allin_withdraw` 是 `public => false`，前台没有归档页；`create_posts` 被关掉，只能由提现处理器创建。

## 验收

```bash
bash /opt/aurora-tests/test-affiliate.sh     # 46 条
```

覆盖：码生成/稳定/唯一/大小写、归属写一次、自邀拒绝、闭环拒绝、一级 10%、二级 3%、回调重放不二次入账、充值不计佣金、提现即时扣款、超额与低于门槛不建单、打款不再动钱、驳回退款、重复驳回不重复退款、REST 401/字段、页面三种状态。

## 上线前

- 佣金比例按毛利设，别超过毛利；充值订单的豁免不要去掉。
- 提现门槛不要低于打款手续费，否则会被小额提现刷成本。
- `withdraw_min` 改小之前想清楚：这笔钱是真金白银。
