# 模块：手机号验证码登录

## 功能说明

- 手机号 + 短信验证码注册/登录，未注册的手机号自动建号（随机密码）。
- 已登录时用同一入口可把手机号**绑定**到当前账号；号码已属其他账号时拒绝（409）。
- 验证码：只存 HMAC 哈希；5 次错误作废；用一次即失效；默认 6 位、5 分钟有效。
- 频率：每号每日 10 条、每 IP 每 10 分钟 5 条；**校验失败不扣配额**。

## 配置项（设置 → Allin Pro → 短信）

| 键 | 默认 | 说明 |
| --- | --- | --- |
| `enabled` | 开 | 是否启用本模块 |
| `provider` | `sandbox` | 服务商：`sandbox` / `aliyun` / `tencent` |
| `code_length` | 6 | 验证码位数（4–8） |
| `code_ttl` | 300 | 有效期（秒） |
| `daily_limit` | 10 | 每号每日上限 |

## 接口

| 动作 | 方法 | 说明 |
| --- | --- | --- |
| `wp_ajax_nopriv_allin_sms_send` | POST | 参数 `phone`、`nonce`（`allin_sms`） |
| `wp_ajax_nopriv_allin_sms_login` | POST | 参数 `phone`、`code`、`nonce` |

短代码：`[allin_sms_login]`。

## 钩子

- `allin_pro_sms_sandbox_sent( $phone, $code )`
- `allin_pro_phone_user_created( $user_id, $phone )`

## 验收清单

1. 非法手机号 → 400，且不消耗配额。
2. 正常号码 → 沙箱日志出现 `phone -> code`，响应里**没有**验证码。
3. 错误验证码 → 400；正确验证码 → 200 并建立登录 cookie。
4. 同一验证码再提交 → 400（已作废）。
5. 后台关闭模块后，`allin_sms_send` 不再响应。
