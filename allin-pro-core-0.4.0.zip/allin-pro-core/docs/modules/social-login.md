# 模块：社交登录

## 功能说明

- 支持 微信（开放平台）/ QQ / 微博 / GitHub，渠道可配。
- 未登录：按第三方身份找到本地账号并登录；沙箱模式下使用每渠道一个演示账号。
- 已登录：把第三方身份**绑定**到当前账号（同一身份不能绑到两个账号）。

## 配置项

| 键 | 默认 | 说明 |
| --- | --- | --- |
| `enabled` | 开 | 是否启用 |
| `providers` | `wechat,qq,weibo,github` | 启用的渠道，逗号分隔 |

## 路由

`/allin-oauth/{provider}/`

- 真实通道必须带 `state`，与 `allin_oauth_state_{provider}` 瞬态比对，不匹配 400。
- 未知渠道 → 回首页。

## 数据

`{prefix}allin_identities`：`provider` + `identifier` 唯一键。用户 meta `allin_oauth_{provider}` 冗余一份。

## 短代码

`[allin_social_login]` — 按主题既有按钮样式输出渠道按钮。

## 验收清单

1. `/allin-oauth/wechat/` → 302，演示账号建立，身份行写入。
2. 已登录访问 `/allin-oauth/qq/` → 302 且 `?allin_bound=qq`。
3. `/allin-oauth/nope/` → 302 回首页。
4. `/wp-json/allin/v1/login-methods` 列出四个渠道及是否沙箱。
