# 模块：支付通道（适配器）

## 功能说明

一套接口接所有支付方式，结账代码不需要知道背后是微信、支付宝还是易支付。

目前内置六个通道：`wechat`、`alipay`、`payjs`、`xunhu`（迅虎）、`epay`（易支付）、`codepay`（码支付）。
**缺商户密钥时自动使用沙箱**：下单后进入本地模拟收银台，点"模拟支付成功"即走完整条链路，订单在站点账本里变成已支付，权益、积分、邮件、通知照常触发。

订单状态只有一个写入者：本模块确认收款后调用站点自带的 `aurora_mark_order_paid()`，自己不改状态、不发货、不授权。

## 适配器契约

```php
id()          // wechat / alipay …
title()       // 显示名
is_sandbox()  // 是否是模拟实现
create($order)      // ['type'=>'redirect|qrcode|form', 'url', 'txn']
query($order)       // ['status'=>'paid|pending|closed']
verify($request)    // 回调签名校验
parse($request)     // ['order_no','amount','txn','status']
refund($refund)     // ['status'=>'success','refund_no']
```

接入真实通道：实现上面的方法后注册，缺配置时自动退回沙箱。

```php
add_filter( 'allin_pro_pay_adapter', function ( $adapter, $id ) {
    if ( 'alipay' !== $id ) {
        return $adapter;
    }
    return AllinPro_Alipay_Real::is_configured() ? new AllinPro_Alipay_Real() : $adapter;
}, 10, 2 );
```

## 配置项（设置 → Allin Pro → 支付通道）

| 键 | 默认 | 说明 |
| --- | --- | --- |
| `pay_gateways` | 六个全开 | 逗号分隔的启用列表，顺序即展示顺序 |

## 端点

| 端点 | 方法 | 说明 |
| --- | --- | --- |
| `/wp-json/allin/v1/pay/gateways` | GET | 通道清单与是否沙箱 |
| `/wp-json/allin/v1/pay/notify/{gateway}` | POST | 统一回调，签名头 `X-Allin-Signature` |
| `/?allin_pay=1&order=ID&gateway=x` | GET | 沙箱收银台（需登录且为订单本人） |
| `admin-post.php?action=allin_pay_confirm` | POST | 沙箱确认，带 nonce |

## 安全约定

- **金额只用于对账**：回调里的金额必须等于账本记录的金额，不等直接 400；价格永远不从请求里取。
- 回调必须验签（HMAC-SHA256，`hash_equals` 常数时间比较），签名缺失即 400。
- 回调与确认都是幂等的：重复回调返回 200，不会二次授权或二次发货。
- 收银台只对订单本人与管理员开放；未登录跳登录页；别人的订单 404。
- 沙箱确认需要 nonce；失败状态的通知不会把订单标成已支付。

## 验收清单

1. `GET /allin/v1/pay/gateways` 返回六个通道，未配置时全部 `sandbox: true`。
2. 下单后进入沙箱收银台，金额与订单一致，带 nonce 与"模拟支付成功/失败"。
3. 无 nonce 提交 → 403；本人提交 → 302 且订单变 `paid`；重复提交不会产生重复状态。
4. 回调：错签名 400、金额被改 400、正确签名 200，订单变已支付，重复回调仍 200。
5. `failed` 状态的通知返回 200 但订单保持未支付。
6. 关闭某个通道后它从清单消失，`?allin_pay` 对该通道返回 404。
