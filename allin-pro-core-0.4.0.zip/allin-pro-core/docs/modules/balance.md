# 模块：余额账户与充值

## 功能说明

- 每个用户一个余额账户，一份**只追加**的流水账；余额 = 账户行，流水 = 怎么来的。
- 充值：选金额 → 生成一张普通订单（带 `_allin_recharge_amount` 标记）→ 走任意支付通道 → 订单支付成功时入账一次。
- 消费：结账时多出一个「余额支付」通道，扣款成功后订单直接完成。
- 运营：`wp allin balance get|credit` 与 REST 调整接口，人工补款/扣款都进流水，有据可查。

## 为什么这样存

- **并发安全**：扣款是一条条件 UPDATE —— `UPDATE ... SET balance = balance - x WHERE user_id = ? AND balance >= x`，数据库保证只有一笔能成功。README 里"读余额→判断→写回"的写法在并发下会透支两条。
- **幂等**：流水表 `UNIQUE (user_id, ref, type)`，`ref` 是订单号。支付回调重放不会二次入账；唯一键冲突时回滚账户变更并返回当前余额。
- **可对账**：每行都记 `balance_after`，任意时点能用流水重算出余额并比对。

## 数据表

| 表 | 说明 |
| --- | --- |
| `{prefix}allin_balance_accounts` | `user_id` 主键，`balance`，`updated_at` |
| `{prefix}allin_balance_ledger` | `delta`、`type`、`ref`、`note`、`balance_after`、`created_at` |

## API

| 方法 | 说明 |
| --- | --- |
| `AllinPro_Balance::balance($uid)` | 当前余额（无账户返回 0.00） |
| `AllinPro_Balance::credit($uid,$amount,$type,$ref,$note)` | 入账，幂等 |
| `AllinPro_Balance::debit($uid,$amount,$type,$ref,$note)` | 扣款，不足返回 `WP_Error('allin_balance_low')` |
| `AllinPro_Balance::entries($uid,$limit)` | 最近流水，倒序 |

`type` 取值：`recharge` / `purchase` / `refund` / `commission` / `withdraw` / `adjust`。

## REST

| 路由 | 方法 | 权限 | 说明 |
| --- | --- | --- | --- |
| `/allin/v1/balance` | GET | 登录 | `{balance, entries[]}` |
| `/allin/v1/balance/adjust` | POST | `manage_options` | `{user_id, amount, note}`，正数入账负数扣款 |

cookie 认证的 REST 请求需要 `X-WP-Nonce`，否则 WordPress 会按未登录处理。

## 短代码与页面

| 短代码 | 页面 |
| --- | --- |
| `[allin_recharge]` | `/recharge` 账户充值 |
| `[allin_balance]` | `/balance` 余额与明细 |

## 钩子

- `allin_pro_balance_moved( $user_id, $delta, $type, $after )`
- 入账/扣款成功后是否发货由订单流程负责，本模块不改订单状态（余额支付除外：扣款成功才标记已支付）。

## 边界

- 充值金额 1–50000，两位小数；预设值可在设置 → Allin Pro → 余额改。
- 充值表单**不提供余额支付**，避免"用余额充余额"的循环。
- 余额不足：订单标记 `cancelled`，余额不动，买家回到订单页看到提示。
- 管理员可以扣款到负数吗？**不可以**，扣款同样走条件 UPDATE。

## 验收清单

1. 新账户余额 0.00；入账 100 后流水一行、`balance_after=100`。
2. 同一 `ref` 重复入账不改变余额，流水仍一行。
3. 扣 30 余 70；扣 70.01 返回 `allin_balance_low` 且余额不变、无流水。
4. 恰好扣光到 0 允许，余额不出现负数。
5. 并发两笔 80 扣 100：只成功一笔，余额 20。
6. 充值订单支付后入账一次，重复支付动作不再入账。
7. 余额支付成功：订单 `paid`、余额减少等于订单金额；余额不足：订单 `cancelled`、余额不变。
8. 游客看不到「余额支付」通道，登录用户能看到。
9. `/allin/v1/balance` 未登录 401；订阅者调用调整接口 403；管理员调整生效。
