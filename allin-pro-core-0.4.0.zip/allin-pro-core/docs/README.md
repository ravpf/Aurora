# Allin Pro Core

站点业务内核插件。与主题解耦：主题只管外观、响应式、SEO 与暗黑模式；会员、付费、商城、社区、导航、微信生态都在这里，模块可单独开关。

## 目录

```
allin-pro-core/
├─ allin-pro-core.php          启动、常量、激活/停用、适配器注册
├─ includes/
│  ├─ functions.php            日志、手机号规范化、验证码签发/校验
│  ├─ class-settings.php       单一 option + schema（默认值只在 schema 里写一次）
│  ├─ class-adapters.php       适配器注册表 + 抽象基类
│  ├─ class-migrations.php     版本化迁移（dbDelta，跑过的不再跑）
│  ├─ class-modules.php        模块注册表与开关
│  ├─ adapters/                各通道的沙箱实现
│  ├─ modules/                 业务模块（短信登录、社交登录、REST）
│  └─ admin/                   后台设置页
├─ assets/                     登录组件用的一点点 CSS/JS（复用主题 token）
└─ docs/                       本文档
```

## 安装

1. 复制 `allin-pro-core/` 到 `wp-content/plugins/`。
2. 后台「插件」启用。启用时自动建表、写入默认设置、刷新重写规则。
3. 打开 **设置 → Allin Pro**，按需填写。

不需要主题配合才能启用；主题缺失时后台与 REST 依然可用。

## 沙箱模式

默认开启。含义：**任何没有配置密钥的第三方通道，自动使用模拟实现**，让完整流程在没有真实资质的情况下也能走通。

- 短信：验证码不发送，写入 `uploads/allin-pro/logs/YYYY-MM.log`（该目录已被 nginx/apache 拒绝直接访问，返回 403）。
- 社交登录：`/allin-oauth/{wechat|qq|weibo|github}/` 会以对应渠道的演示账号登录，并写入身份绑定表。
- 上线前：关掉「全局沙箱模式」并填入真实密钥，或通过 `allin_pro_register_adapters` 注册真实适配器。

**沙箱验证码永远不进浏览器响应**，只在服务端日志里；测试对此有断言。

## 适配器契约

```php
abstract class AllinPro_Adapter {
    abstract public function name();          // 通道名
    abstract public function is_available();  // 密钥齐、契约满足 → true
    abstract public function is_sandbox();    // 是否是模拟实现
}
```

注册真实通道：

```php
add_action( 'allin_pro_register_adapters', function ( $registry ) {
    $registry->register( 'sms', 'aliyun', function () {
        return new My_Aliyun_Sms(); // 继承 AllinPro_Adapter，实现 send()
    } );
} );
```

注册表按「首选通道 → 沙箱」顺序解析，**真实通道不可用时自动降级**，调用方不需要写 if。

## 钩子与过滤器

| 名称 | 类型 | 用途 |
| --- | --- | --- |
| `allin_pro_settings_schema` | filter | 追加设置页签与字段 |
| `allin_pro_pay_adapter` | filter | 接管某个支付通道（真实现优先级 10，沙箱 20） |
| `allin_pro_referral_bound` | action | 新用户完成归属绑定（`$user_id, $referrer`） |
| `allin_pro_commission_paid` | action | 佣金已入账（`$order_id, $paid[]`） |
| `allin_pro_modules` | filter | 追加/覆盖模块注册表 |
| `allin_pro_register_adapters` | action | 注册真实第三方适配器 |
| `allin_pro_sms_sandbox_sent` | action | 沙箱"发送"后触发（`$phone, $code`） |
| `allin_pro_phone_user_created` | action | 手机号注册完成（`$user_id, $phone`） |
| `allin_pro_login_redirect` | filter | 登录后跳转地址 |

## REST

命名空间 `allin/v1`：

| 路由 | 方法 | 权限 | 说明 |
| --- | --- | --- | --- |
| `/ping` | GET | 公开 | `ok` / `version` / `db` / `sandbox` / `time` |
| `/login-methods` | GET | 公开 | 短信是否开启、各渠道列表与是否沙箱 |
| `/modules` | GET | `manage_options` | 模块清单与开关状态 |
| `/me` | GET | 登录 | 用户、角色、手机号、已绑定身份 |
| `/pay/gateways` | GET | 公开 | 可用支付通道（沙箱标注） |
| `/pay/notify/{gateway}` | POST | 公开（验签） | 统一支付回调 |
| `/balance` | GET | 登录 | 余额账户与近期流水 |
| `/balance/adjust` | POST | `manage_options` | 人工调账 |
| `/referral` | GET | 登录 | 推广码、链接、已邀请、佣金、余额 |

## 数据表

| 表 | 用途 |
| --- | --- |
| `{prefix}allin_codes` | 验证码（只存 HMAC 哈希，带尝试次数、过期、使用时间） |
| `{prefix}allin_identities` | 第三方身份绑定（`provider` + `identifier` 唯一） |
| `{prefix}allin_balance_accounts` | 每用户一行余额 |
| `{prefix}allin_balance_ledger` | 只追加流水（`user_id + ref + type` 唯一） |

迁移版本存于 `allin_pro_db_version`，`AllinPro_Migrations::run()` 可重复调用。

## 安全约定

- 验证码只存哈希，5 次错误作废，用一次即失效。
- 每号每日上限 + 每 IP 每 10 分钟 5 次，**校验失败不占配额**。
- 日志目录禁止 HTTP 访问（nginx `^~ /wp-content/uploads/allin-pro/` + `.htaccess`）。
- 停用插件不删数据。
