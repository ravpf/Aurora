/* Allin Pro — SMS login widget. No framework, no build step. */
(function () {
  function post(ajax, data) {
    var body = new FormData();
    Object.keys(data).forEach(function (k) { body.append(k, data[k]); });
    return fetch(ajax, { method: 'POST', body: body, credentials: 'same-origin' })
      .then(function (r) { return r.json(); });
  }

  function msg(el, text, ok) {
    if (!el) return;
    el.textContent = text;
    el.className = 'aurora-newsletter__hint ' + (ok ? 'is-ok' : 'is-err');
  }

  document.addEventListener('click', function (e) {
    var send = e.target.closest('[data-allin-sms-send]');
    var login = e.target.closest('[data-allin-sms-login]');
    var form = e.target.closest('.allin-sms');
    if (!form) return;

    var out = form.querySelector('[data-allin-sms-msg]');
    var phoneEl = form.querySelector('#allin-phone') || form.querySelector('input[type=tel]');
    var codeEl = form.querySelector('#allin-code');

    if (send) {
      e.preventDefault();
      send.disabled = true;
      post(send.getAttribute('data-ajax'), {
        action: 'allin_sms_send',
        nonce: send.getAttribute('data-nonce'),
        phone: phoneEl ? phoneEl.value : ''
      }).then(function (res) {
        send.disabled = false;
        msg(out, (res.data && res.data.message) || '发送失败', res.success);
      }).catch(function () { send.disabled = false; msg(out, '网络异常，请重试。', false); });
      return;
    }

    if (login) {
      e.preventDefault();
      post(login.getAttribute('data-ajax'), {
        action: 'allin_sms_login',
        nonce: login.getAttribute('data-nonce'),
        phone: phoneEl ? phoneEl.value : '',
        code: codeEl ? codeEl.value : ''
      }).then(function (res) {
        msg(out, (res.data && res.data.message) || '登录失败', res.success);
        if (res.success) {
          var to = res.data.redirect || location.href;
          setTimeout(function () { location.href = to; }, 600);
        }
      }).catch(function () { msg(out, '网络异常，请重试。', false); });
    }
  });
})();
