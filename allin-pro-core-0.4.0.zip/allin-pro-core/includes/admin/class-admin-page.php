<?php
/**
 * Settings screen.
 *
 * Tabs come from the schema, so a module that adds a field through the filter
 * also gets a working tab without touching this file.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin page.
 */
final class AllinPro_Admin_Page {

	/**
	 * Instance.
	 *
	 * @var AllinPro_Admin_Page|null
	 */
	private static $instance = null;

	/**
	 * Instance accessor.
	 *
	 * @return AllinPro_Admin_Page
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			add_action( 'admin_menu', array( self::$instance, 'menu' ) );
			add_action( 'admin_post_allin_pro_save', array( self::$instance, 'save' ) );
		}

		return self::$instance;
	}

	/**
	 * Menu entry.
	 */
	public function menu() {
		add_options_page(
			__( 'Allin Pro 设置', 'allin-pro' ),
			__( 'Allin Pro', 'allin-pro' ),
			'manage_options',
			'allin-pro',
			array( $this, 'render' )
		);
	}

	/**
	 * Save the submitted tab.
	 */
	public function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '没有权限。', 'allin-pro' ), 403 );
		}

		check_admin_referer( 'allin_pro_save' );

		$settings = AllinPro_Settings::instance();
		$schema   = $settings->schema();
		$tab      = isset( $_POST['tab'] ) ? sanitize_key( wp_unslash( $_POST['tab'] ) ) : 'general';
		$values   = array();

		foreach ( $schema[ $tab ]['fields'] ?? array() as $key => $field ) {
			$raw = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : null;

			switch ( $field['type'] ) {
				case 'checkbox':
					$values[ $key ] = $raw ? 1 : 0;
					break;
				case 'number':
					$values[ $key ] = (int) $raw;
					break;
				case 'select':
					$values[ $key ] = isset( $field['options'][ $raw ] ) ? $raw : $field['default'];
					break;
				default:
					$values[ $key ] = sanitize_text_field( (string) $raw );
			}
		}

		// Module switches live on the modules tab, not in the schema tabs.
		if ( 'modules' === $tab ) {
			$off = array();

			foreach ( array_keys( AllinPro_Modules::instance()->registry() ) as $key ) {
				if ( empty( $_POST['module_' . $key ] ) ) {
					$off[] = $key;
				}
			}

			$values['modules_off'] = $off;
		}

		if ( $values ) {
			$settings->update( $values );
		}

		allin_pro_log( 'settings', sprintf( 'tab=%s by user #%d', $tab, get_current_user_id() ) );

		wp_safe_redirect( add_query_arg( array( 'page' => 'allin-pro', 'tab' => $tab, 'saved' => '1' ), admin_url( 'options-general.php' ) ) );
		exit;
	}

	/**
	 * Screen.
	 */
	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings = AllinPro_Settings::instance();
		$schema   = $settings->schema();
		$tab      = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general';
		$tabs     = $schema;

		$tabs['modules'] = array( 'label' => __( '模块', 'allin-pro' ) );

		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'general';
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Allin Pro 设置', 'allin-pro' ); ?></h1>

			<?php if ( isset( $_GET['saved'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( '已保存。', 'allin-pro' ); ?></p></div>
			<?php endif; ?>

			<h2 class="nav-tab-wrapper">
				<?php foreach ( $tabs as $key => $group ) : ?>
					<a class="nav-tab <?php echo $key === $tab ? 'nav-tab-active' : ''; ?>"
						href="<?php echo esc_url( add_query_arg( array( 'page' => 'allin-pro', 'tab' => $key ), admin_url( 'options-general.php' ) ) ); ?>">
						<?php echo esc_html( $group['label'] ); ?>
					</a>
				<?php endforeach; ?>
			</h2>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="allin_pro_save">
				<input type="hidden" name="tab" value="<?php echo esc_attr( $tab ); ?>">
				<?php wp_nonce_field( 'allin_pro_save' ); ?>

				<table class="form-table" role="presentation">
					<?php if ( 'modules' === $tab ) : ?>
						<?php foreach ( AllinPro_Modules::instance()->registry() as $key => $module ) : ?>
							<tr>
								<th scope="row"><?php echo esc_html( $module['label'] ); ?></th>
								<td>
									<label>
										<input type="checkbox" name="module_<?php echo esc_attr( $key ); ?>" value="1"
											<?php checked( AllinPro_Modules::instance()->enabled( $key ) ); ?>>
										<?php esc_html_e( '启用', 'allin-pro' ); ?>
									</label>
									<p class="description"><?php echo esc_html( $module['desc'] ); ?></p>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<?php foreach ( $schema[ $tab ]['fields'] as $key => $field ) : ?>
							<tr>
								<th scope="row"><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
								<td>
									<?php $value = $settings->get( $key ); ?>

									<?php if ( 'checkbox' === $field['type'] ) : ?>
										<input type="checkbox" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" value="1" <?php checked( (int) $value, 1 ); ?>>
									<?php elseif ( 'select' === $field['type'] ) : ?>
										<select id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>">
											<?php foreach ( $field['options'] as $opt_key => $opt_label ) : ?>
												<option value="<?php echo esc_attr( $opt_key ); ?>" <?php selected( $value, $opt_key ); ?>><?php echo esc_html( $opt_label ); ?></option>
											<?php endforeach; ?>
										</select>
									<?php elseif ( 'number' === $field['type'] ) : ?>
										<input type="number" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( (string) $value ); ?>" class="small-text">
									<?php else : ?>
										<input type="text" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( (string) $value ); ?>" class="regular-text">
									<?php endif; ?>

									<?php if ( ! empty( $field['help'] ) ) : ?>
										<p class="description"><?php echo esc_html( $field['help'] ); ?></p>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</table>

				<?php submit_button( __( '保存设置', 'allin-pro' ) ); ?>
			</form>

			<h2><?php esc_html_e( '适配器状态', 'allin-pro' ); ?></h2>
			<table class="widefat striped" style="max-width:720px">
				<thead><tr>
					<th><?php esc_html_e( '类型', 'allin-pro' ); ?></th>
					<th><?php esc_html_e( '通道', 'allin-pro' ); ?></th>
					<th><?php esc_html_e( '可用', 'allin-pro' ); ?></th>
					<th><?php esc_html_e( '沙箱', 'allin-pro' ); ?></th>
				</tr></thead>
				<tbody>
				<?php foreach ( array( 'sms', 'oauth' ) as $kind ) : ?>
					<?php foreach ( AllinPro_Adapters::instance()->status( $kind ) as $name => $state ) : ?>
						<tr>
							<td><?php echo esc_html( strtoupper( $kind ) ); ?></td>
							<td><?php echo esc_html( $name ); ?></td>
							<td><?php echo $state['available'] ? '✓' : '—'; ?></td>
							<td><?php echo $state['sandbox'] ? esc_html__( '是', 'allin-pro' ) : esc_html__( '否', 'allin-pro' ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endforeach; ?>
				</tbody>
			</table>

			<h2><?php esc_html_e( '最近日志', 'allin-pro' ); ?></h2>
			<pre style="max-width:900px;max-height:240px;overflow:auto;background:#f6f7f7;padding:12px;border-radius:6px"><?php echo esc_html( allin_pro_log_tail( 30 ) ); ?></pre>
		</div>
		<?php
	}
}
