<?php
/**
 * One option, one schema, one place to read it from.
 *
 * Every module reads settings through get() so a missing key never produces an
 * undefined-index warning, and defaults live in the schema rather than being
 * repeated at call sites.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Settings store.
 */
final class AllinPro_Settings {

	/**
	 * Instance.
	 *
	 * @var AllinPro_Settings|null
	 */
	private static $instance = null;

	/**
	 * Cached values.
	 *
	 * @var array|null
	 */
	private $cache = null;

	/**
	 * Instance accessor.
	 *
	 * @return AllinPro_Settings
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * The schema: group => field => [type, default, label, help].
	 *
	 * @return array
	 */
	public function schema() {
		$schema = array(
			'general' => array(
				'label'  => __( '通用', 'allin-pro' ),
				'fields' => array(
					'site_mode'   => array(
						'type'    => 'select',
						'default' => 'mixed',
						'label'   => __( '站点形态', 'allin-pro' ),
						'help'    => __( '只影响默认首页与导航推荐，不锁定任何模块。', 'allin-pro' ),
						'options' => array(
							'mixed'   => __( '资讯 + 社区 + 商城（混合）', 'allin-pro' ),
							'news'    => __( '资讯站', 'allin-pro' ),
							'forum'   => __( '社区 / 论坛', 'allin-pro' ),
							'shop'    => __( '商城 / 知识付费', 'allin-pro' ),
							'nav'     => __( '导航 / 目录站', 'allin-pro' ),
						),
					),
					'sandbox'     => array(
						'type'    => 'checkbox',
						'default' => 1,
						'label'   => __( '全局沙箱模式', 'allin-pro' ),
						'help'    => __( '打开时，所有缺密钥的第三方接口走模拟实现，流程可完整跑通；上线前关掉并填好密钥。', 'allin-pro' ),
					),
					'debug_log'   => array(
						'type'    => 'checkbox',
						'default' => 1,
						'label'   => __( '记录适配器调用日志', 'allin-pro' ),
						'help'    => __( '写入 uploads/allin-pro/logs，不含密钥。', 'allin-pro' ),
					),
				),
			),
			'sms'     => array(
				'label'  => __( '短信', 'allin-pro' ),
				'fields' => array(
					'enabled'      => array(
						'type'    => 'checkbox',
						'default' => 1,
						'label'   => __( '启用手机号验证码登录', 'allin-pro' ),
					),
					'provider'     => array(
						'type'    => 'select',
						'default' => 'sandbox',
						'label'   => __( '服务商', 'allin-pro' ),
						'options' => array(
							'sandbox' => __( '沙箱（不发真短信）', 'allin-pro' ),
							'aliyun'  => __( '阿里云短信', 'allin-pro' ),
							'tencent' => __( '腾讯云短信', 'allin-pro' ),
						),
					),
					'code_length'  => array(
						'type'    => 'number',
						'default' => 6,
						'label'   => __( '验证码位数', 'allin-pro' ),
					),
					'code_ttl'     => array(
						'type'    => 'number',
						'default' => 300,
						'label'   => __( '有效期（秒）', 'allin-pro' ),
					),
					'daily_limit'  => array(
						'type'    => 'number',
						'default' => 10,
						'label'   => __( '每号每日上限', 'allin-pro' ),
					),
				),
			),
			'oauth'   => array(
				'label'  => __( '社交登录', 'allin-pro' ),
				'fields' => array(
					'enabled'  => array(
						'type'    => 'checkbox',
						'default' => 1,
						'label'   => __( '启用社交登录', 'allin-pro' ),
					),
					'providers' => array(
						'type'    => 'text',
						'default' => 'wechat,qq,weibo,github',
						'label'   => __( '启用的渠道', 'allin-pro' ),
						'help'    => __( '逗号分隔：wechat（微信开放平台）、qq、weibo、github。没有配置密钥的渠道自动使用沙箱。', 'allin-pro' ),
					),
				),
			),
		);

		$schema['balance'] = array(
			'label'  => __( '余额', 'allin-pro' ),
			'fields' => array(
				'recharge_presets' => array(
					'type'    => 'text',
					'default' => '10,30,50,100,200',
					'label'   => __( '充值预设金额', 'allin-pro' ),
					'help'    => __( '逗号分隔，第一个作为默认选中。自定义金额上限 50000。', 'allin-pro' ),
				),
			),
		);

		$schema['affiliate'] = array(
			'label'  => __( '推广分销', 'allin-pro' ),
			'fields' => array(
				'commission_rate'   => array(
					'type'    => 'number',
					'default' => 0.1,
					'label'   => __( '一级佣金比例', 'allin-pro' ),
					'help'    => __( '0.1 表示 10%。按订单实付金额计算，充值订单不计佣金。', 'allin-pro' ),
				),
				'commission_rate_2' => array(
					'type'    => 'number',
					'default' => 0,
					'label'   => __( '二级佣金比例', 'allin-pro' ),
					'help'    => __( '0 表示关闭二级。上限 30%。', 'allin-pro' ),
				),
				'withdraw_min'      => array(
					'type'    => 'number',
					'default' => 10,
					'label'   => __( '提现门槛（元）', 'allin-pro' ),
				),
			),
		);

		$schema['payments'] = array(
			'label'  => __( '支付通道', 'allin-pro' ),
			'fields' => array(
				'pay_gateways' => array(
					'type'    => 'text',
					'default' => 'wechat,alipay,payjs,xunhu,epay,codepay',
					'label'   => __( '启用的通道', 'allin-pro' ),
					'help'    => __( '逗号分隔。缺商户密钥的通道自动使用沙箱：下单后进入本地模拟收银台，可完整跑到订单已支付。真实密钥请通过 WP-CLI 或配置文件注入，不要写进页面。', 'allin-pro' ),
				),
			),
		);

		/**
		 * Filter the settings schema so a child plugin can add tabs/fields.
		 *
		 * @param array $schema Schema.
		 */
		return apply_filters( 'allin_pro_settings_schema', $schema );
	}

	/**
	 * Stored values.
	 *
	 * @return array
	 */
	public function all() {
		if ( null === $this->cache ) {
			$stored      = get_option( ALLIN_PRO_OPTION, array() );
			$this->cache = is_array( $stored ) ? $stored : array();
		}

		return $this->cache;
	}

	/**
	 * One setting, with schema default.
	 *
	 * @param string $key     Field key.
	 * @param mixed  $default Fallback when the schema has no entry.
	 * @return mixed
	 */
	public function get( $key, $default = null ) {
		$all = $this->all();

		if ( array_key_exists( $key, $all ) ) {
			return $all[ $key ];
		}

		foreach ( $this->schema() as $group ) {
			if ( isset( $group['fields'][ $key ] ) ) {
				return $group['fields'][ $key ]['default'];
			}
		}

		return $default;
	}

	/**
	 * Save a set of values (already sanitised by the caller).
	 *
	 * @param array $values Values.
	 */
	public function update( array $values ) {
		$all = array_merge( $this->all(), $values );

		update_option( ALLIN_PRO_OPTION, $all );

		$this->cache = $all;
	}

	/**
	 * Seed defaults the first time the plugin is activated.
	 */
	public function seed_defaults() {
		if ( get_option( ALLIN_PRO_OPTION ) ) {
			return;
		}

		$defaults = array();

		foreach ( $this->schema() as $group ) {
			foreach ( $group['fields'] as $key => $field ) {
				$defaults[ $key ] = $field['default'];
			}
		}

		update_option( ALLIN_PRO_OPTION, $defaults );
		$this->cache = $defaults;
	}
}
