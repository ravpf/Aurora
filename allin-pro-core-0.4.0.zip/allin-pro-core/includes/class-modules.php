<?php
/**
 * Module loader.
 *
 * A module is a class with static register() that hooks itself. Anything can be
 * switched off from the admin page; a module that is off simply never registers
 * its hooks, so it costs nothing on a site that does not use it.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Loader.
 */
final class AllinPro_Modules {

	/**
	 * Instance.
	 *
	 * @var AllinPro_Modules|null
	 */
	private static $instance = null;

	/**
	 * Registry: key => [label, class, requires].
	 *
	 * @var array
	 */
	private $registry = array();

	/**
	 * Instance accessor.
	 *
	 * @return AllinPro_Modules
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Everything this version ships.
	 *
	 * @return array
	 */
	public function registry() {
		$registry = array(
			'sms_login'    => array(
				'label'    => __( '手机号验证码登录', 'allin-pro' ),
				'class'    => 'AllinPro_Sms_Login',
				'requires' => 'sms',
				'desc'     => __( '手机号 + 短信验证码注册/登录，可绑定到已有账号。', 'allin-pro' ),
			),
			'social_login' => array(
				'label'    => __( '社交登录', 'allin-pro' ),
				'class'    => 'AllinPro_Social_Login',
				'requires' => 'oauth',
				'desc'     => __( '微信 / QQ / 微博 / GitHub 一键登录，身份与本地账号绑定。', 'allin-pro' ),
			),
			'rest_api'     => array(
				'label'    => __( 'REST API', 'allin-pro' ),
				'class'    => 'AllinPro_Rest',
				'requires' => '',
				'desc'     => __( 'allin/v1 命名空间：站点能力自述、模块清单、登录方式。', 'allin-pro' ),
			),
		);

		/**
		 * Filter the module registry.
		 *
		 * @param array $registry Registry.
		 */
		return apply_filters( 'allin_pro_modules', $registry );
	}

	/**
	 * Is a module switched on?
	 *
	 * @param string $key Module key.
	 * @return bool
	 */
	public function enabled( $key ) {
		$off = (array) AllinPro_Settings::instance()->get( 'modules_off', array() );

		return ! in_array( $key, $off, true );
	}

	/**
	 * Boot every enabled module whose adapter dependency is satisfied.
	 */
	public function boot() {
		foreach ( $this->registry() as $key => $module ) {
			if ( ! $this->enabled( $key ) ) {
				continue;
			}

			if ( $module['requires'] && ! AllinPro_Settings::instance()->get( $module['requires'] . '_enabled', 1 ) ) {
				continue;
			}

			if ( ! class_exists( $module['class'] ) || ! method_exists( $module['class'], 'register' ) ) {
				continue;
			}

			call_user_func( array( $module['class'], 'register' ) );
		}
	}

	/**
	 * Rewrite rules owned by modules (called on activation).
	 */
	public function register_rewrites() {
		add_rewrite_rule( '^allin-auth/([a-z]+)/?$', 'index.php?allin_auth=$matches[1]', 'top' );
		add_rewrite_tag( '%allin_auth%', '([a-z]+)' );
	}
}
