<?php
/**
 * Versioned migrations.
 *
 * The schema version is stored, and each step runs once. Re-activating the
 * plugin runs whatever is still pending and nothing more, which is what makes
 * it safe to deploy over a live site.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Migrations.
 */
final class AllinPro_Migrations {

	const OPTION = 'allin_pro_db_version';

	/**
	 * Steps in order: version => callable.
	 *
	 * @return array
	 */
	public static function steps() {
		return array(
			'0.1.0' => array( __CLASS__, 'migration_0_1_0' ),
			'0.3.0' => array( __CLASS__, 'migration_0_3_0' ),
		);
	}

	/**
	 * Current schema version.
	 *
	 * @return string
	 */
	public static function version() {
		return (string) get_option( self::OPTION, '0' );
	}

	/**
	 * Run every pending step.
	 *
	 * @return array<string,string> version => 'ran'|'skipped'
	 */
	public static function run() {
		$done   = self::version();
		$result = array();

		foreach ( self::steps() as $version => $callable ) {
			if ( version_compare( $done, $version, '>=' ) ) {
				$result[ $version ] = 'skipped';
				continue;
			}

			call_user_func( $callable );

			update_option( self::OPTION, $version );
			$result[ $version ] = 'ran';
		}

		return $result;
	}

	/**
	 * 0.1.0 — verification codes and social identities.
	 */
	public static function migration_0_1_0() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();

		$codes = "CREATE TABLE {$wpdb->prefix}allin_codes (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			target varchar(191) NOT NULL,
			purpose varchar(32) NOT NULL DEFAULT 'login',
			code_hash varchar(64) NOT NULL,
			attempts smallint(5) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			expires_at datetime NOT NULL,
			used_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY target_purpose (target,purpose),
			KEY expires_at (expires_at)
		) $charset;";

		$identities = "CREATE TABLE {$wpdb->prefix}allin_identities (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			provider varchar(32) NOT NULL,
			identifier varchar(191) NOT NULL,
			profile longtext NULL,
			created_at datetime NOT NULL,
			last_login datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY provider_identifier (provider,identifier),
			KEY user_id (user_id)
		) $charset;";

		dbDelta( $codes );
		dbDelta( $identities );

		update_option( 'allin_pro_tables', array( 'allin_codes', 'allin_identities' ) );
	}

	/**
	 * Balance accounts and their ledger.
	 *
	 * The balance lives in one row per user so a debit can be a single
	 * conditional UPDATE ("... WHERE balance >= x"), which is what makes
	 * concurrent spending safe. The ledger is append-only: the account row says
	 * what the balance is, the ledger says how it got there and who did it.
	 *
	 * UNIQUE (user_id, ref, type) is the idempotency key: a replayed payment
	 * callback cannot credit the same order twice.
	 */
	public static function migration_0_3_0() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();

		$accounts = "CREATE TABLE {$wpdb->prefix}allin_balance_accounts (
			user_id bigint(20) unsigned NOT NULL,
			balance decimal(12,2) NOT NULL DEFAULT 0.00,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (user_id),
			KEY balance (balance)
		) $charset;";

		$ledger = "CREATE TABLE {$wpdb->prefix}allin_balance_ledger (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			delta decimal(12,2) NOT NULL,
			type varchar(32) NOT NULL DEFAULT 'adjust',
			ref varchar(64) NOT NULL DEFAULT '',
			note varchar(191) NOT NULL DEFAULT '',
			balance_after decimal(12,2) NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY user_ref_type (user_id,ref,type),
			KEY user_created (user_id,created_at)
		) $charset;";

		dbDelta( $accounts );
		dbDelta( $ledger );

		$tables   = (array) get_option( 'allin_pro_tables', array() );
		$tables[] = 'allin_balance_accounts';
		$tables[] = 'allin_balance_ledger';

		update_option( 'allin_pro_tables', array_values( array_unique( $tables ) ) );
	}
}
