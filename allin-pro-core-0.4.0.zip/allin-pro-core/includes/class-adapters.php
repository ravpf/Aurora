<?php
/**
 * Adapter registry.
 *
 * Every third-party integration is resolved through here. The contract is the
 * same for all of them: prefer a real implementation when keys exist, otherwise
 * hand back the sandbox so a site without merchant credentials can still walk
 * through the whole flow.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registry.
 */
final class AllinPro_Adapters {

	/**
	 * Instance.
	 *
	 * @var AllinPro_Adapters|null
	 */
	private static $instance = null;

	/**
	 * Registered factories: kind => [name => callable].
	 *
	 * @var array
	 */
	private $factories = array();

	/**
	 * Resolved instances.
	 *
	 * @var array
	 */
	private $resolved = array();

	/**
	 * Instance accessor.
	 *
	 * @return AllinPro_Adapters
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register an adapter factory.
	 *
	 * @param string   $kind    sms|oauth|pay|search.
	 * @param string   $name    Provider name.
	 * @param callable $factory Returns an adapter instance.
	 */
	public function register( $kind, $name, callable $factory ) {
		$this->factories[ $kind ][ $name ] = $factory;
	}

	/**
	 * Resolve an adapter, falling back to its sandbox when the provider is
	 * unavailable or not configured.
	 *
	 * @param string $kind     Kind.
	 * @param string $provider Preferred provider.
	 * @return AllinPro_Adapter|null
	 */
	public function get( $kind, $provider = '' ) {
		$provider = $provider ? $provider : (string) AllinPro_Settings::instance()->get( $kind . '_provider', 'sandbox' );
		$cache    = $kind . '|' . $provider;

		if ( isset( $this->resolved[ $cache ] ) ) {
			return $this->resolved[ $cache ];
		}

		$candidates = array( $provider );

		// Anything that is not usable falls back to the sandbox, and the reason
		// is recorded so the admin page can show why.
		if ( 'sandbox' !== $provider ) {
			$candidates[] = 'sandbox';
		}

		foreach ( $candidates as $name ) {
			if ( empty( $this->factories[ $kind ][ $name ] ) ) {
				continue;
			}

			$adapter = call_user_func( $this->factories[ $kind ][ $name ] );

			if ( $adapter instanceof AllinPro_Adapter && $adapter->is_available() ) {
				$this->resolved[ $cache ] = $adapter;
				return $adapter;
			}
		}

		return null;
	}

	/**
	 * Which providers are registered for a kind, with availability.
	 *
	 * @param string $kind Kind.
	 * @return array
	 */
	public function status( $kind ) {
		$out = array();

		foreach ( array_keys( $this->factories[ $kind ] ?? array() ) as $name ) {
			$adapter = call_user_func( $this->factories[ $kind ][ $name ] );

			$out[ $name ] = array(
				'available' => $adapter instanceof AllinPro_Adapter ? $adapter->is_available() : false,
				'sandbox'   => $adapter instanceof AllinPro_Adapter ? $adapter->is_sandbox() : false,
			);
		}

		return $out;
	}
}

/**
 * Adapter contract.
 */
abstract class AllinPro_Adapter {

	/**
	 * Provider name.
	 *
	 * @return string
	 */
	abstract public function name();

	/**
	 * Is this adapter usable right now (keys present, contract met)?
	 *
	 * @return bool
	 */
	abstract public function is_available();

	/**
	 * Is this the simulated implementation?
	 *
	 * @return bool
	 */
	abstract public function is_sandbox();
}
