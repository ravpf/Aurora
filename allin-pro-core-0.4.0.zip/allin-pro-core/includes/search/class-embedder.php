<?php
/**
 * Text embedding.
 *
 * Two implementations behind one interface:
 *
 * - `local` computes vectors in PHP with the hashing trick over character
 *   n-grams plus a small synonym map. It is NOT a neural model and does not
 *   pretend to be: it matches wording and the synonyms listed in
 *   `allin_pro_search_synonyms()`. It exists so search works on a server with
 *   no API key and no outbound calls.
 * - `remote` calls an OpenAI-compatible /embeddings endpoint. It is only used
 *   when a key is configured; without one the callers get a WP_Error and fall
 *   back, they never get a fake vector.
 *
 * A vector is identified by `kind` (which vector space it lives in). The index
 * stores that per row, because comparing a 256-dim hashed vector with a
 * 1536-dim model vector is meaningless — the query uses the same kind the rows
 * were built with, and falls back to keyword scoring when it cannot.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Shared contract.
 */
interface AllinPro_Embedder {

	/**
	 * Identifier for the vector space this embedder produces.
	 *
	 * @return string
	 */
	public function kind();

	/**
	 * Embed texts.
	 *
	 * @param string[] $texts Inputs.
	 * @return array<int,float[]>|WP_Error One vector per input.
	 */
	public function embed( array $texts );
}

/**
 * Local, dependency-free embedder.
 */
final class AllinPro_Embedder_Local implements AllinPro_Embedder {

	/**
	 * Vector width. Fixed so an index built yesterday still compares today.
	 */
	const DIM = 256;

	/**
	 * Kind.
	 *
	 * @return string
	 */
	public function kind() {
		return 'local:' . self::DIM;
	}

	/**
	 * Embed.
	 *
	 * @param string[] $texts Inputs.
	 * @return array<int,float[]>
	 */
	public function embed( array $texts ) {
		$out = array();

		foreach ( $texts as $text ) {
			$out[] = $this->vector( (string) $text );
		}

		return $out;
	}

	/**
	 * Normalise text into features.
	 *
	 * Latin words keep their whole form and a 4-character prefix (so "install"
	 * and "installation" share a feature); CJK is cut into bigrams, because one
	 * character alone is too common to carry meaning.
	 *
	 * @param string $text Text.
	 * @return string[]
	 */
	public static function features( $text ) {
		$text = wp_strip_all_tags( (string) $text );
		$text = mb_strtolower( $text, 'UTF-8' );
		$text = preg_replace( '/[^\p{Han}\p{L}\p{N}]+/u', ' ', $text );
		$text = trim( (string) $text );

		$features = array();

		if ( '' === $text ) {
			return $features;
		}

		foreach ( preg_split( '/\s+/u', $text ) as $word ) {
			if ( '' === $word ) {
				continue;
			}

			if ( preg_match( '/^\p{Han}+$/u', $word ) ) {
				$len   = mb_strlen( $word, 'UTF-8' );
				$chars = preg_split( '//u', $word, -1, PREG_SPLIT_NO_EMPTY );

				if ( 1 === $len ) {
					$features[] = $word;
					continue;
				}

				for ( $i = 0; $i < $len - 1; $i++ ) {
					$features[] = $chars[ $i ] . $chars[ $i + 1 ];
				}

				if ( $len > 3 ) {
					$features[] = $chars[0] . $chars[1] . $chars[2];
				}

				continue;
			}

			$features[] = $word;

			if ( mb_strlen( $word, 'UTF-8' ) > 4 ) {
				$features[] = 'pre:' . mb_substr( $word, 0, 4, 'UTF-8' );
			}
		}

		// 同义词把「多少钱」和「价格」接上：这是本地通道唯一的"语义"来源。
		foreach ( allin_pro_search_synonyms() as $canonical => $aliases ) {
			foreach ( $aliases as $alias ) {
				if ( false !== mb_strpos( $text, $alias, 0, 'UTF-8' ) ) {
					$features[] = 'syn:' . $canonical;
					break;
				}
			}
		}

		return $features;
	}

	/**
	 * Build one normalised vector.
	 *
	 * @param string $text Text.
	 * @return float[]
	 */
	public function vector( $text ) {
		$vec = array_fill( 0, self::DIM, 0.0 );

		$features = self::features( $text );
		if ( ! $features ) {
			return $vec;
		}

		$tf = array_count_values( $features );

		foreach ( $tf as $feature => $count ) {
			$slot = hexdec( substr( md5( (string) $feature ), 0, 8 ) ) % self::DIM;
			$sign = ( hexdec( substr( md5( (string) $feature ), 8, 2 ) ) % 2 ) ? 1.0 : -1.0;

			// Sub-linear term frequency: the tenth repeat of a word does not
			// matter ten times as much as the first.
			$vec[ $slot ] += $sign * ( 1.0 + log( (float) $count ) );
		}

		return self::normalise( $vec );
	}

	/**
	 * L2 normalise.
	 *
	 * @param float[] $vec Vector.
	 * @return float[]
	 */
	public static function normalise( array $vec ) {
		$sum = 0.0;

		foreach ( $vec as $v ) {
			$sum += (float) $v * (float) $v;
		}

		if ( $sum <= 0.0 ) {
			return $vec;
		}

		$norm = sqrt( $sum );

		foreach ( $vec as $i => $v ) {
			$vec[ $i ] = (float) $v / $norm;
		}

		return $vec;
	}
}

/**
 * OpenAI-compatible embeddings.
 */
final class AllinPro_Embedder_Remote implements AllinPro_Embedder {

	/**
	 * Base URL (…/v1).
	 *
	 * @var string
	 */
	private $base;

	/**
	 * Model.
	 *
	 * @var string
	 */
	private $model;

	/**
	 * Key.
	 *
	 * @var string
	 */
	private $key;

	/**
	 * Constructor.
	 *
	 * @param string $base  Base URL.
	 * @param string $model Model.
	 * @param string $key   API key.
	 */
	public function __construct( $base, $model, $key ) {
		$this->base  = untrailingslashit( (string) $base );
		$this->model = (string) $model;
		$this->key   = (string) $key;
	}

	/**
	 * Kind.
	 *
	 * @return string
	 */
	public function kind() {
		return 'remote:' . $this->model;
	}

	/**
	 * Embed.
	 *
	 * @param string[] $texts Inputs.
	 * @return array<int,float[]>|WP_Error
	 */
	public function embed( array $texts ) {
		if ( '' === $this->key ) {
			return new WP_Error( 'allin_no_key', __( '没有配置向量模型密钥。', 'allin-pro' ) );
		}

		$response = wp_remote_post(
			$this->base . '/embeddings',
			array(
				'timeout' => 20,
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'input' => array_values( $texts ),
						'model' => $this->model,
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code || ! isset( $body['data'] ) || ! is_array( $body['data'] ) ) {
			return new WP_Error(
				'allin_embed_failed',
				sprintf(
					/* translators: %d: HTTP status */
					__( '向量服务返回 %d。', 'allin-pro' ),
					$code
				)
			);
		}

		$out = array();

		foreach ( $body['data'] as $row ) {
			$vec   = isset( $row['embedding'] ) ? (array) $row['embedding'] : array();
			$out[] = AllinPro_Embedder_Local::normalise( array_map( 'floatval', $vec ) );
		}

		return count( $out ) === count( $texts )
			? $out
			: new WP_Error( 'allin_embed_count', __( '向量条数与输入不一致。', 'allin-pro' ) );
	}
}

/**
 * Resolve the embedder for the current settings.
 *
 * @return AllinPro_Embedder
 */
function allin_pro_embedder() {
	$settings = AllinPro_Settings::instance()->all();

	$provider = isset( $settings['search_provider'] ) ? (string) $settings['search_provider'] : 'local';
	$base     = isset( $settings['search_api_base'] ) ? (string) $settings['search_api_base'] : '';
	$model    = isset( $settings['search_model'] ) ? (string) $settings['search_model'] : 'text-embedding-3-small';
	$key      = isset( $settings['search_api_key'] ) ? (string) $settings['search_api_key'] : '';

	$embedder = new AllinPro_Embedder_Local();

	if ( 'remote' === $provider && '' !== $key && '' !== $base && '' !== $model ) {
		$embedder = new AllinPro_Embedder_Remote( $base, $model, $key );
	}

	/**
	 * Swap the embedder (a site may run a local model server instead).
	 *
	 * @param AllinPro_Embedder $embedder Embedder.
	 */
	return apply_filters( 'allin_pro_embedder', $embedder );
}

/**
 * Small, editable synonym map.
 *
 * This is a curated list, not a learned model. It is the honest limit of the
 * local channel: queries that use different wording for the same idea only
 * match when the idea is in here.
 *
 * @return array<string,string[]>
 */
function allin_pro_search_synonyms() {
	$map = array(
		'价格' => array( '多少钱', '收费', '费用', '定价', '贵不贵' ),
		'会员' => array( 'vip', '订阅', '开通' ),
		'登录' => array( '登陆', 'sign in', '登入' ),
		'注册' => array( 'sign up', '开户' ),
		'部署' => array( '上线', '发布到服务器', 'nginx', '宝塔' ),
		'配色' => array( '主题色', '暗黑', '深色模式', '深浅色' ),
		'支付' => array( '付款', '结账', '收银台', 'pay' ),
		'退款' => array( '退钱', '售后' ),
		'缓存' => array( 'cache', '不更新', '还是旧的' ),
		'速度' => array( '性能', '慢', '优化', '加载' ),
	);

	/**
	 * Filter the synonym map.
	 *
	 * @param array<string,string[]> $map Canonical => aliases.
	 */
	return apply_filters( 'allin_pro_search_synonyms', $map );
}
