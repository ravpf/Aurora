<?php
/**
 * The search index.
 *
 * One row per post: the embedder kind it was built with, the vector, and the
 * plain text used for keyword scoring. Rows are written when a post is saved
 * and removed when it is deleted or unpublished — an index that keeps retracted
 * posts is worse than no index, because search will happily show them.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Index writer / reader.
 */
final class AllinPro_Search_Index {

	/**
	 * Table name.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;

		return $wpdb->prefix . 'allin_search_index';
	}

	/**
	 * Post types worth indexing.
	 *
	 * @return string[]
	 */
	public static function types() {
		return apply_filters( 'allin_pro_search_types', array( 'post', 'page', 'aurora_notice' ) );
	}

	/**
	 * Create the table if it is missing (used by the migration and by rebuild).
	 */
	public static function ensure() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$table   = self::table();

		$sql = "CREATE TABLE $table (
			post_id bigint(20) unsigned NOT NULL,
			kind varchar(48) NOT NULL DEFAULT '',
			dim smallint(5) unsigned NOT NULL DEFAULT 0,
			vector longblob NULL,
			title text NOT NULL,
			body longtext NOT NULL,
			terms varchar(512) NOT NULL DEFAULT '',
			updated_at datetime NOT NULL,
			PRIMARY KEY  (post_id),
			KEY kind_dim (kind,dim)
		) $charset;";

		dbDelta( $sql );
	}

	/**
	 * Text that goes into a row.
	 *
	 * Title is repeated: it is the strongest signal a post has, and the local
	 * embedder counts occurrences.
	 *
	 * @param int $post_id Post.
	 * @return array{title:string,body:string,terms:string,text:string}|null
	 */
	public static function payload( $post_id ) {
		$post = get_post( $post_id );

		if ( ! $post || 'publish' !== $post->post_status || ! in_array( $post->post_type, self::types(), true ) ) {
			return null;
		}

		$title = get_the_title( $post );
		$body  = wp_strip_all_tags( (string) $post->post_excerpt . ' ' . (string) $post->post_content );
		$body  = trim( preg_replace( '/\s+/u', ' ', $body ) );

		$tags = array();

		foreach ( array( 'post_tag', 'category', 'aurora_board' ) as $tax ) {
			$terms = get_the_terms( $post, $tax );

			if ( $terms && ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$tags[] = $term->name;
				}
			}
		}

		$terms = implode( ' ', array_unique( $tags ) );

		return array(
			'title' => $title,
			'body'  => $body,
			'terms' => $terms,
			'text'  => trim( $title . ' ' . $title . ' ' . $title . ' ' . $terms . ' ' . $body ),
		);
	}

	/**
	 * Index one post.
	 *
	 * @param int $post_id Post.
	 * @return bool True when a row was written.
	 */
	public static function index_post( $post_id ) {
		global $wpdb;

		$post_id  = (int) $post_id;
		$payload  = self::payload( $post_id );

		if ( ! $payload ) {
			self::remove( $post_id );
			return false;
		}

		$embedder = allin_pro_embedder();
		$kind     = (string) $embedder->kind();
		$vectors  = $embedder->embed( array( $payload['text'] ) );

		if ( is_wp_error( $vectors ) || ! isset( $vectors[0] ) ) {
			// 向量服务挂了也要能搜：留一行没有向量的记录，检索时按关键词打分。
			$vectors = array( array() );
			$kind    = 'keyword-only';
		}

		$vector = $vectors[0];
		$blob   = $vector ? pack( 'f*', ...$vector ) : '';

		$wpdb->replace(
			self::table(),
			array(
				'post_id'    => $post_id,
				'kind'       => $kind,
				'dim'        => count( $vector ),
				'vector'     => $blob,
				'title'      => $payload['title'],
				'body'       => $payload['body'],
				'terms'      => mb_substr( $payload['terms'], 0, 500, 'UTF-8' ),
				'updated_at' => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s' )
		);

		return true;
	}

	/**
	 * Drop a post from the index.
	 *
	 * @param int $post_id Post.
	 */
	public static function remove( $post_id ) {
		global $wpdb;

		$wpdb->delete( self::table(), array( 'post_id' => (int) $post_id ), array( '%d' ) );
	}

	/**
	 * Rebuild every row.
	 *
	 * @param int $per_page Batch size.
	 * @return array{pages:int,indexed:int,removed:int}
	 */
	public static function rebuild( $per_page = 100 ) {
		global $wpdb;

		self::ensure();

		$per_page = max( 1, (int) $per_page );
		$page     = 1;
		$indexed  = 0;
		$seen     = array();

		do {
			$ids = get_posts(
				array(
					'post_type'        => self::types(),
					'post_status'      => 'publish',
					'posts_per_page'   => $per_page,
					'paged'            => $page,
					'fields'           => 'ids',
					'orderby'          => 'ID',
					'order'            => 'ASC',
					'suppress_filters' => true,
				)
			);

			foreach ( $ids as $id ) {
				if ( self::index_post( (int) $id ) ) {
					$indexed++;
				}
				$seen[] = (int) $id;
			}

			$page++;
		} while ( count( $ids ) === $per_page );

		// 索引里留着已删/已下线的帖子，就会把不该出现的内容搜出来。
		$removed = 0;

		$rows = $wpdb->get_col( 'SELECT post_id FROM ' . self::table() ); // phpcs:ignore WordPress.DB.PreparedSQL

		foreach ( $rows as $row ) {
			if ( ! in_array( (int) $row, $seen, true ) ) {
				self::remove( (int) $row );
				$removed++;
			}
		}

		return array(
			'pages'   => $page - 1,
			'indexed' => $indexed,
			'removed' => $removed,
		);
	}

	/**
	 * Rows for a vector space.
	 *
	 * @param string $kind Embedder kind.
	 * @return array<int,array<string,mixed>>
	 */
	public static function rows( $kind ) {
		global $wpdb;

		$table = self::table();
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, dim, vector, title, body, terms FROM $table WHERE kind = %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$kind
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Counts for the admin screen.
	 *
	 * @return array{rows:int,posts:int,kind:string,stale:int}
	 */
	public static function stats() {
		global $wpdb;

		$table = self::table();
		$rows  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$kind  = (string) allin_pro_embedder()->kind();
		$live  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE kind = '" . esc_sql( $kind ) . "'" ); // phpcs:ignore WordPress.DB.PreparedSQL

		return array(
			'rows'   => $rows,
			'posts'  => $live,
			'kind'   => $kind,
			'stale'  => max( 0, $rows - $live ),
		);
	}
}
