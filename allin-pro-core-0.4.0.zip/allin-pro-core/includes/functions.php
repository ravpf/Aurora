<?php
/**
 * Shared helpers.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Append a line to the plugin log (uploads/allin-pro/logs/YYYY-MM.log).
 *
 * Never logs secrets: the caller decides what is safe to write.
 *
 * @param string $channel Channel.
 * @param string $message Message.
 */
function allin_pro_log( $channel, $message ) {
	if ( ! AllinPro_Settings::instance()->get( 'debug_log', 1 ) ) {
		return;
	}

	$dir = wp_upload_dir()['basedir'] . '/allin-pro/logs';

	if ( ! wp_mkdir_p( $dir ) ) {
		return;
	}

	$file = $dir . '/' . gmdate( 'Y-m' ) . '.log';
	$line = sprintf( "[%s] [%s] %s\n", gmdate( 'Y-m-d H:i:s' ), $channel, str_replace( "\n", ' ', (string) $message ) );

	@file_put_contents( $file, $line, FILE_APPEND | LOCK_EX ); // phpcs:ignore
}

/**
 * Last N log lines for the admin page.
 *
 * @param int $lines Lines.
 * @return string
 */
function allin_pro_log_tail( $lines = 40 ) {
	$file = wp_upload_dir()['basedir'] . '/allin-pro/logs/' . gmdate( 'Y-m' ) . '.log';

	if ( ! is_readable( $file ) ) {
		return '';
	}

	$all = file( $file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES );

	return implode( "\n", array_slice( (array) $all, -absint( $lines ) ) );
}

/**
 * Normalise a mainland mobile number, or return '' when it is not one.
 *
 * @param string $phone Raw input.
 * @return string
 */
function allin_pro_normalize_phone( $phone ) {
	$phone = preg_replace( '/[^0-9]/', '', (string) $phone );

	if ( 0 === strpos( $phone, '86' ) && 13 === strlen( $phone ) ) {
		$phone = substr( $phone, 2 );
	}

	return preg_match( '/^1[3-9]\d{9}$/', $phone ) ? $phone : '';
}

/**
 * Issue a verification code for a target.
 *
 * The plain code is returned once, to the caller that has to deliver it; the
 * table only ever holds a hash.
 *
 * @param string $target  Phone or email.
 * @param string $purpose login|bind|reset.
 * @return array{code:string,expires:int}|WP_Error
 */
function allin_pro_code_issue( $target, $purpose = 'login' ) {
	global $wpdb;

	$settings = AllinPro_Settings::instance();
	$length   = max( 4, min( 8, (int) $settings->get( 'code_length', 6 ) ) );
	$ttl      = max( 60, (int) $settings->get( 'code_ttl', 300 ) );

	$recent = (int) $wpdb->get_var(
		$wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}allin_codes WHERE target=%s AND purpose=%s AND created_at >= %s",
			$target,
			$purpose,
			gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS )
		)
	);

	if ( $recent >= max( 1, (int) $settings->get( 'daily_limit', 10 ) ) ) {
		return new WP_Error( 'allin_daily_limit', __( '今天这个号码的验证码次数用完了。', 'allin-pro' ) );
	}

	$code = (string) random_int( 10 ** ( $length - 1 ), ( 10 ** $length ) - 1 );

	$wpdb->insert(
		"{$wpdb->prefix}allin_codes",
		array(
			'target'     => $target,
			'purpose'    => $purpose,
			'code_hash'  => hash_hmac( 'sha256', $code, wp_salt( 'auth' ) ),
			'attempts'   => 0,
			'created_at' => gmdate( 'Y-m-d H:i:s' ),
			'expires_at' => gmdate( 'Y-m-d H:i:s', time() + $ttl ),
		),
		array( '%s', '%s', '%s', '%d', '%s', '%s' )
	);

	// Purge anything long expired so the table cannot grow forever.
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}allin_codes WHERE expires_at < %s", gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS ) ) );

	return array( 'code' => $code, 'expires' => $ttl );
}

/**
 * Check a code. Five wrong guesses burn it.
 *
 * @param string $target Target.
 * @param string $code   Code.
 * @param string $purpose Purpose.
 * @return true|WP_Error
 */
function allin_pro_code_verify( $target, $code, $purpose = 'login' ) {
	global $wpdb;

	$row = $wpdb->get_row(
		$wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}allin_codes
			 WHERE target=%s AND purpose=%s AND used_at IS NULL AND expires_at >= %s
			 ORDER BY id DESC LIMIT 1",
			$target,
			$purpose,
			gmdate( 'Y-m-d H:i:s' )
		)
	);

	if ( ! $row ) {
		return new WP_Error( 'allin_code_missing', __( '验证码已失效，请重新获取。', 'allin-pro' ) );
	}

	if ( (int) $row->attempts >= 5 ) {
		return new WP_Error( 'allin_code_burned', __( '错误次数过多，请重新获取验证码。', 'allin-pro' ) );
	}

	if ( ! hash_equals( $row->code_hash, hash_hmac( 'sha256', (string) $code, wp_salt( 'auth' ) ) ) ) {
		$wpdb->update( "{$wpdb->prefix}allin_codes", array( 'attempts' => (int) $row->attempts + 1 ), array( 'id' => (int) $row->id ), array( '%d' ), array( '%d' ) );

		return new WP_Error( 'allin_code_wrong', __( '验证码不对。', 'allin-pro' ) );
	}

	$wpdb->update( "{$wpdb->prefix}allin_codes", array( 'used_at' => gmdate( 'Y-m-d H:i:s' ) ), array( 'id' => (int) $row->id ), array( '%s' ), array( '%d' ) );

	return true;
}

/**
 * Find a user by phone number.
 *
 * @param string $phone Phone.
 * @return WP_User|null
 */
function allin_pro_user_by_phone( $phone ) {
	$users = get_users(
		array(
			'meta_key'   => 'allin_phone',
			'meta_value' => $phone,
			'number'     => 1,
			'fields'     => 'all',
		)
	);

	return $users ? $users[0] : null;
}
