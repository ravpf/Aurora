<?php
/**
 * SMS sandbox.
 *
 * Sends nothing. The code is written to a log the admin can read, which is the
 * only way to finish a phone-login flow on a machine with no SMS account.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sandbox SMS provider.
 */
class AllinPro_Sms_Sandbox extends AllinPro_Adapter {

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function name() {
		return 'sandbox';
	}

	/**
	 * Always available.
	 *
	 * @return bool
	 */
	public function is_available() {
		return true;
	}

	/**
	 * Sandbox.
	 *
	 * @return bool
	 */
	public function is_sandbox() {
		return true;
	}

	/**
	 * "Send" a code.
	 *
	 * @param string $phone Phone.
	 * @param string $code  Code.
	 * @return true|WP_Error
	 */
	public function send( $phone, $code ) {
		allin_pro_log( 'sms', sprintf( 'sandbox: %s -> %s', $phone, $code ) );

		/**
		 * Fires after a sandbox SMS was "sent"; useful for tests and demos.
		 *
		 * @param string $phone Phone.
		 * @param string $code  Code.
		 */
		do_action( 'allin_pro_sms_sandbox_sent', $phone, $code );

		return true;
	}
}
