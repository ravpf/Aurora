<?php
/**
 * OAuth sandbox.
 *
 * Stands in for every channel that has no app key yet so the buttons, the
 * callback and the identity binding can all be exercised locally.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sandbox OAuth provider.
 */
class AllinPro_Oauth_Sandbox extends AllinPro_Adapter {

	/**
	 * Provider key.
	 *
	 * @var string
	 */
	private $provider;

	/**
	 * Constructor.
	 *
	 * @param string $provider Provider.
	 */
	public function __construct( $provider = 'wechat' ) {
		$this->provider = $provider;
	}

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function name() {
		return $this->provider;
	}

	/**
	 * Available while sandbox is on.
	 *
	 * @return bool
	 */
	public function is_available() {
		return (bool) AllinPro_Settings::instance()->get( 'sandbox', 1 );
	}

	/**
	 * Sandbox.
	 *
	 * @return bool
	 */
	public function is_sandbox() {
		return true;
	}
}
