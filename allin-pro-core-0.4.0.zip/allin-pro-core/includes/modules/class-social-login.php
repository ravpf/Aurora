<?php
/**
 * Social login.
 *
 * Real providers need app keys and a public HTTPS callback; without them the
 * sandbox provider signs in a per-channel demo account so the whole flow —
 * buttons, callback, identity binding, welcome redirect — can be walked through
 * on a local machine.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Providers.
 */
class AllinPro_Social_Login {

	/**
	 * Supported channels.
	 *
	 * @return array
	 */
	public static function providers() {
		$all = array(
			'wechat' => __( '微信', 'allin-pro' ),
			'qq'     => __( 'QQ', 'allin-pro' ),
			'weibo'  => __( '微博', 'allin-pro' ),
			'github' => __( 'GitHub', 'allin-pro' ),
		);

		$enabled = array_filter( array_map( 'trim', explode( ',', (string) AllinPro_Settings::instance()->get( 'providers', 'wechat,qq,weibo,github' ) ) ) );

		return array_intersect_key( $all, array_flip( $enabled ) );
	}

	/**
	 * Hook everything.
	 */
	public static function register() {
		add_action( 'init', array( __CLASS__, 'add_rewrite' ), 9 );
		add_action( 'template_redirect', array( __CLASS__, 'handle_callback' ), 2 );
		add_shortcode( 'allin_social_login', array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_ajax_nopriv_allin_social_start', array( __CLASS__, 'ajax_start' ) );
	}

	/**
	 * Callback route.
	 */
	public static function add_rewrite() {
		add_rewrite_rule( '^allin-oauth/([a-z]+)/?$', 'index.php?allin_oauth=$matches[1]', 'top' );
		add_rewrite_tag( '%allin_oauth%', '([a-z]+)' );
	}

	/**
	 * Is the site in sandbox mode for this channel?
	 *
	 * @param string $provider Provider.
	 * @return bool
	 */
	public static function is_sandbox( $provider ) {
		$adapter = AllinPro_Adapters::instance()->get( 'oauth', $provider );

		return ! $adapter || $adapter->is_sandbox();
	}

	/**
	 * Handle /allin-oauth/{provider}/.
	 */
	public static function handle_callback() {
		$provider = get_query_var( 'allin_oauth' );

		if ( ! $provider ) {
			return;
		}

		$providers = self::providers();

		if ( ! isset( $providers[ $provider ] ) ) {
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}

		if ( ! self::is_sandbox( $provider ) ) {
			// A real provider must present a state value it issued; anything
			// else is rejected rather than logged in.
			$state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
			$kept  = get_transient( 'allin_oauth_state_' . $provider );

			if ( ! $state || ! $kept || ! hash_equals( (string) $kept, $state ) ) {
				wp_die( esc_html__( '登录状态已失效，请重新发起登录。', 'allin-pro' ), 400 );
			}
		}

		if ( is_user_logged_in() ) {
			// Binding while logged in: attach this identity to the current user.
			self::link_identity( get_current_user_id(), $provider, 'demo-' . $provider );

			wp_safe_redirect( add_query_arg( 'allin_bound', $provider, home_url( '/' ) ) );
			exit;
		}

		$user = self::sandbox_user( $provider );

		if ( is_wp_error( $user ) ) {
			wp_die( esc_html( $user->get_error_message() ) );
		}

		wp_set_current_user( $user->ID );
		wp_set_auth_cookie( $user->ID, true );
		do_action( 'wp_login', $user->user_login, $user );

		wp_safe_redirect( apply_filters( 'allin_pro_login_redirect', home_url( '/' ), $user ) );
		exit;
	}

	/**
	 * Demo account for a channel (sandbox only).
	 *
	 * @param string $provider Provider.
	 * @return WP_User|WP_Error
	 */
	private static function sandbox_user( $provider ) {
		$login = 'demo_' . $provider;

		$user = get_user_by( 'login', $login );

		if ( ! $user ) {
			$id = wp_insert_user(
				array(
					'user_login'   => $login,
					'user_pass'    => wp_generate_password( 32, true, true ),
					'user_email'   => $login . '@oauth.invalid',
					'display_name' => sprintf( '%s 演示账号', ucfirst( $provider ) ),
					'role'         => get_option( 'default_role', 'subscriber' ),
				)
			);

			if ( is_wp_error( $id ) ) {
				return $id;
			}

			$user = get_user_by( 'id', $id );
		}

		self::link_identity( $user->ID, $provider, 'demo-' . $provider );

		return $user;
	}

	/**
	 * Record (or refresh) an identity binding.
	 *
	 * @param int    $user_id    User.
	 * @param string $provider   Provider.
	 * @param string $identifier Provider-side id.
	 * @return bool
	 */
	public static function link_identity( $user_id, $provider, $identifier ) {
		global $wpdb;

		$table = $wpdb->prefix . 'allin_identities';

		$existing = $wpdb->get_var(
			$wpdb->prepare( "SELECT user_id FROM {$table} WHERE provider=%s AND identifier=%s", $provider, $identifier )
		);

		if ( $existing && (int) $existing !== (int) $user_id ) {
			return false;
		}

		if ( $existing ) {
			$wpdb->update( $table, array( 'last_login' => gmdate( 'Y-m-d H:i:s' ) ), array( 'user_id' => (int) $user_id, 'provider' => $provider, 'identifier' => $identifier ) );
		} else {
			$wpdb->insert(
				$table,
				array(
					'user_id'    => (int) $user_id,
					'provider'   => $provider,
					'identifier' => $identifier,
					'created_at' => gmdate( 'Y-m-d H:i:s' ),
					'last_login' => gmdate( 'Y-m-d H:i:s' ),
				)
			);
		}

		update_user_meta( $user_id, 'allin_oauth_' . $provider, $identifier );

		return true;
	}

	/**
	 * Identities bound to a user.
	 *
	 * @param int $user_id User.
	 * @return array provider => identifier
	 */
	public static function identities( $user_id ) {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT provider, identifier FROM {$wpdb->prefix}allin_identities WHERE user_id=%d", $user_id )
		);

		$out = array();

		foreach ( (array) $rows as $row ) {
			$out[ $row->provider ] = $row->identifier;
		}

		return $out;
	}

	/**
	 * Buttons.
	 *
	 * @return string
	 */
	public static function shortcode() {
		$providers = self::providers();

		if ( ! $providers ) {
			return '';
		}

		ob_start();
		?>
		<div class="allin-social">
			<?php foreach ( $providers as $key => $label ) : ?>
				<a class="aurora-btn aurora-btn--ghost allin-social__btn" href="<?php echo esc_url( home_url( '/allin-oauth/' . $key . '/' ) ); ?>">
					<?php echo esc_html( sprintf( /* translators: %s: channel. */ __( '用%s登录', 'allin-pro' ), $label ) ); ?>
				</a>
			<?php endforeach; ?>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}
