<?php
/**
 * REST surface.
 *
 * Everything a client (mini program, app, static front end) needs to discover
 * the site's shape without reading the database: what is installed, what is on,
 * which login methods are offered, whether the site is running in sandbox.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * REST module.
 */
class AllinPro_Rest {

	const NS = 'allin/v1';

	/**
	 * Hook.
	 */
	public static function register() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/**
	 * Routes.
	 */
	public static function routes() {
		register_rest_route(
			self::NS,
			'/ping',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'callback'            => array( __CLASS__, 'ping' ),
			)
		);

		register_rest_route(
			self::NS,
			'/login-methods',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'callback'            => array( __CLASS__, 'login_methods' ),
			)
		);

		register_rest_route(
			self::NS,
			'/modules',
			array(
				'methods'             => 'GET',
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
				'callback'            => array( __CLASS__, 'modules' ),
			)
		);

		register_rest_route(
			self::NS,
			'/me',
			array(
				'methods'             => 'GET',
				'permission_callback' => 'is_user_logged_in',
				'callback'            => array( __CLASS__, 'me' ),
			)
		);
	}

	/**
	 * Liveness + version + sandbox flag.
	 *
	 * @return WP_REST_Response
	 */
	public static function ping() {
		return rest_ensure_response(
			array(
				'ok'        => true,
				'version'   => ALLIN_PRO_VERSION,
				'db'        => AllinPro_Migrations::version(),
				'sandbox'   => (bool) AllinPro_Settings::instance()->get( 'sandbox', 1 ),
				'time'      => gmdate( 'c' ),
			)
		);
	}

	/**
	 * What a visitor can log in with.
	 *
	 * @return WP_REST_Response
	 */
	public static function login_methods() {
		$providers = AllinPro_Social_Login::providers();
		$out       = array();

		foreach ( $providers as $key => $label ) {
			$out[] = array(
				'key'     => $key,
				'label'   => $label,
				'sandbox' => AllinPro_Social_Login::is_sandbox( $key ),
				'url'     => home_url( '/allin-oauth/' . $key . '/' ),
			);
		}

		return rest_ensure_response(
			array(
				'sms'   => array(
					'enabled' => (bool) AllinPro_Settings::instance()->get( 'enabled', 1 ),
					'sandbox' => (bool) ( AllinPro_Adapters::instance()->get( 'sms' )?->is_sandbox() ?? true ),
				),
				'oauth' => $out,
			)
		);
	}

	/**
	 * Module registry with enabled state (admin only).
	 *
	 * @return WP_REST_Response
	 */
	public static function modules() {
		$loader = AllinPro_Modules::instance();
		$out    = array();

		foreach ( $loader->registry() as $key => $module ) {
			$out[] = array(
				'key'     => $key,
				'label'   => $module['label'],
				'enabled' => $loader->enabled( $key ),
				'class'   => $module['class'],
			);
		}

		return rest_ensure_response( $out );
	}

	/**
	 * Current user, as a client would need it.
	 *
	 * @return WP_REST_Response
	 */
	public static function me() {
		$user = wp_get_current_user();

		return rest_ensure_response(
			array(
				'id'         => $user->ID,
				'name'       => $user->display_name,
				'roles'      => array_values( (array) $user->roles ),
				'phone'      => (string) get_user_meta( $user->ID, 'allin_phone', true ),
				'identities' => AllinPro_Social_Login::identities( $user->ID ),
			)
		);
	}
}
