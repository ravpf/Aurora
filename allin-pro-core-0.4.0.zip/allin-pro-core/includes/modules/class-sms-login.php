<?php
/**
 * Phone + SMS code login.
 *
 * Registration is implicit: a phone number that verifies and has no account yet
 * gets one, with a random password nobody needs to know. Binding an existing
 * account happens through the same endpoint while logged in.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * SMS login module.
 */
class AllinPro_Sms_Login {

	/**
	 * Hook everything.
	 */
	public static function register() {
		add_action( 'wp_ajax_nopriv_allin_sms_send', array( __CLASS__, 'ajax_send' ) );
		add_action( 'wp_ajax_allin_sms_send', array( __CLASS__, 'ajax_send' ) );
		add_action( 'wp_ajax_nopriv_allin_sms_login', array( __CLASS__, 'ajax_login' ) );
		add_action( 'wp_ajax_allin_sms_login', array( __CLASS__, 'ajax_login' ) );
		add_shortcode( 'allin_sms_login', array( __CLASS__, 'shortcode' ) );
	}

	/**
	 * Per-IP throttle: five sends per ten minutes.
	 *
	 * @return bool
	 */
	private static function ip_allowed() {
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '0';
		$key = 'allin_sms_' . md5( $ip );

		// Checking does not consume a slot: a request rejected for a malformed
		// phone number must not eat the visitor's quota.
		return (int) get_transient( $key ) < 5;
	}

	/**
	 * Count one successful send against the IP quota.
	 */
	private static function ip_charge() {
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '0';
		$key = 'allin_sms_' . md5( $ip );

		set_transient( $key, (int) get_transient( $key ) + 1, 10 * MINUTE_IN_SECONDS );
	}

	/**
	 * Send a code.
	 */
	public static function ajax_send() {
		check_ajax_referer( 'allin_sms', 'nonce' );

		$phone = allin_pro_normalize_phone( isset( $_POST['phone'] ) ? wp_unslash( $_POST['phone'] ) : '' );

		if ( ! $phone ) {
			wp_send_json_error( array( 'message' => __( '请输入正确的手机号。', 'allin-pro' ) ), 400 );
		}

		if ( ! self::ip_allowed() ) {
			wp_send_json_error( array( 'message' => __( '请求太频繁，请稍后再试。', 'allin-pro' ) ), 429 );
		}

		$issued = allin_pro_code_issue( $phone, 'login' );

		if ( is_wp_error( $issued ) ) {
			wp_send_json_error( array( 'message' => $issued->get_error_message() ), 429 );
		}

		$adapter = AllinPro_Adapters::instance()->get( 'sms' );
		$sent    = $adapter ? $adapter->send( $phone, $issued['code'] ) : new WP_Error( 'allin_no_sms', __( '短信通道不可用。', 'allin-pro' ) );

		if ( is_wp_error( $sent ) ) {
			wp_send_json_error( array( 'message' => $sent->get_error_message() ), 502 );
		}

		self::ip_charge();

		$sandbox = $adapter && $adapter->is_sandbox();

		wp_send_json_success(
			array(
				'message' => $sandbox
					? __( '沙箱模式：验证码已写入日志，管理员可在「Allin Pro → 短信」查看。', 'allin-pro' )
					: __( '验证码已发送。', 'allin-pro' ),
				'sandbox' => (bool) $sandbox,
				'ttl'     => (int) $issued['expires'],
				// Never expose the code itself to the browser, sandbox or not.
			)
		);
	}

	/**
	 * Verify a code and log the visitor in.
	 */
	public static function ajax_login() {
		check_ajax_referer( 'allin_sms', 'nonce' );

		$phone = allin_pro_normalize_phone( isset( $_POST['phone'] ) ? wp_unslash( $_POST['phone'] ) : '' );
		$code  = sanitize_text_field( isset( $_POST['code'] ) ? wp_unslash( $_POST['code'] ) : '' );

		if ( ! $phone || ! $code ) {
			wp_send_json_error( array( 'message' => __( '手机号和验证码都要填。', 'allin-pro' ) ), 400 );
		}

		$checked = allin_pro_code_verify( $phone, $code, 'login' );

		if ( is_wp_error( $checked ) ) {
			wp_send_json_error( array( 'message' => $checked->get_error_message() ), 400 );
		}

		$user = allin_pro_user_by_phone( $phone );

		if ( $user && is_user_logged_in() && get_current_user_id() !== $user->ID ) {
			wp_send_json_error( array( 'message' => __( '这个手机号已经绑定到别的账号了。', 'allin-pro' ) ), 409 );
		}

		if ( ! $user ) {
			$user = self::create_user( $phone );
		}

		if ( is_wp_error( $user ) ) {
			wp_send_json_error( array( 'message' => $user->get_error_message() ), 500 );
		}

		if ( is_user_logged_in() ) {
			update_user_meta( get_current_user_id(), 'allin_phone', $phone );

			wp_send_json_success(
				array(
					'message'  => __( '手机号已绑定到当前账号。', 'allin-pro' ),
					'bound'    => true,
					'redirect' => '',
				)
			);
		}

		wp_set_current_user( $user->ID );
		wp_set_auth_cookie( $user->ID, true );
		do_action( 'wp_login', $user->user_login, $user );

		wp_send_json_success(
			array(
				'message'  => __( '登录成功。', 'allin-pro' ),
				'bound'    => false,
				'redirect' => apply_filters( 'allin_pro_login_redirect', admin_url( 'profile.php' ), $user ),
			)
		);
	}

	/**
	 * Create an account for a verified phone number.
	 *
	 * @param string $phone Phone.
	 * @return WP_User|WP_Error
	 */
	public static function create_user( $phone ) {
		$login = 'u' . $phone;
		$email = $phone . '@sms.invalid';

		if ( username_exists( $login ) || email_exists( $email ) ) {
			$login .= wp_rand( 100, 999 );
			$email  = $phone . '-' . wp_rand( 100, 999 ) . '@sms.invalid';
		}

		$user_id = wp_insert_user(
			array(
				'user_login'   => $login,
				'user_pass'    => wp_generate_password( 32, true, true ),
				'user_email'   => $email,
				'display_name' => substr( $phone, 0, 3 ) . '****' . substr( $phone, -4 ),
				'role'         => get_option( 'default_role', 'subscriber' ),
			)
		);

		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		update_user_meta( $user_id, 'allin_phone', $phone );

		/**
		 * Fires after a phone account was created.
		 *
		 * @param int    $user_id User.
		 * @param string $phone   Phone.
		 */
		do_action( 'allin_pro_phone_user_created', $user_id, $phone );

		return get_user_by( 'id', $user_id );
	}

	/**
	 * The login form. Written against the theme's existing classes so it picks
	 * up the site's styling instead of inventing a second design language.
	 *
	 * @return string
	 */
	public static function shortcode() {
		if ( is_user_logged_in() ) {
			return '<p class="aurora-empty">' . esc_html__( '你已登录。', 'allin-pro' ) . '</p>';
		}

		ob_start();
		?>
		<form class="allin-sms" method="post" onsubmit="return false;">
			<label for="allin-phone"><?php esc_html_e( '手机号', 'allin-pro' ); ?></label>
			<div class="aurora-newsletter__row">
				<input id="allin-phone" type="tel" inputmode="numeric" autocomplete="tel" placeholder="13800000000" required>
				<button type="button" class="aurora-btn aurora-btn--ghost" data-allin-sms-send
					data-ajax="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>"
					data-nonce="<?php echo esc_attr( wp_create_nonce( 'allin_sms' ) ); ?>">
					<?php esc_html_e( '获取验证码', 'allin-pro' ); ?>
				</button>
			</div>
			<div class="aurora-newsletter__row" style="margin-top:10px">
				<input id="allin-code" type="text" inputmode="numeric" autocomplete="one-time-code" placeholder="<?php esc_attr_e( '短信验证码', 'allin-pro' ); ?>" required>
				<button type="button" class="aurora-btn aurora-btn--primary" data-allin-sms-login
					data-ajax="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>"
					data-nonce="<?php echo esc_attr( wp_create_nonce( 'allin_sms' ) ); ?>">
					<?php esc_html_e( '登录 / 注册', 'allin-pro' ); ?>
				</button>
			</div>
			<p class="aurora-newsletter__hint" data-allin-sms-msg aria-live="polite"></p>
		</form>
		<?php
		return (string) ob_get_clean();
	}
}
