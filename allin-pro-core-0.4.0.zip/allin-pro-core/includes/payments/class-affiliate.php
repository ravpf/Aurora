<?php
/**
 * Referral: codes, attribution, commission.
 *
 * Attribution is deliberately boring: a ?ref= code or a 30-day cookie, bound
 * once at registration, never overwritten. A user cannot refer themselves and
 * a closed loop is refused. Commission is credited to the referrer's balance
 * ledger with the order number as its idempotency key, so the same paid order
 * can never pay out twice even if the callback fires three times.
 *
 * Recharge orders earn no commission. Paying commission on a top-up is how a
 * referral scheme turns into a cash-out machine: buy 100, refer yourself,
 * collect 10, repeat.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

class AllinPro_Affiliate {

	const COOKIE = 'allin_ref';

	/**
	 * Hook up.
	 */
	public static function register() {
		add_action( 'template_redirect', array( __CLASS__, 'capture_code' ), 1 );
		add_action( 'user_register', array( __CLASS__, 'bind_on_register' ), 10, 1 );
		add_action( 'aurora_order_paid', array( __CLASS__, 'commission' ), 15, 2 );
		add_shortcode( 'allin_invite', array( __CLASS__, 'render_invite' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_filter( 'aurora_user_quick_links', array( __CLASS__, 'quick_link' ) );
	}

	/**
	 * A user's code, created on first use.
	 *
	 * @param int $user_id User.
	 * @return string
	 */
	public static function code( $user_id ) {
		$user_id = (int) $user_id;

		if ( $user_id <= 0 ) {
			return '';
		}

		$code = (string) get_user_meta( $user_id, 'allin_ref_code', true );

		if ( $code ) {
			return $code;
		}

		// Six characters is short enough to read out loud; collisions are
		// resolved against the index rather than trusted to luck.
		for ( $i = 0; $i < 8; $i++ ) {
			$candidate = strtoupper( substr( str_shuffle( '23456789ABCDEFGHJKLMNPQRSTUVWXYZ' ), 0, 6 ) );

			$taken = get_users(
				array(
					'number'     => 1,
					'fields'     => 'ID',
					'meta_key'   => 'allin_ref_code',
					'meta_value' => $candidate,
				)
			);

			if ( ! $taken ) {
				update_user_meta( $user_id, 'allin_ref_code', $candidate );

				return $candidate;
			}
		}

		return '';
	}

	/**
	 * User id behind a code.
	 *
	 * @param string $code Code.
	 * @return int
	 */
	public static function owner_of( $code ) {
		$code = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $code ) );

		if ( '' === $code ) {
			return 0;
		}

		$found = get_users(
			array(
				'number'     => 1,
				'fields'     => 'ID',
				'meta_key'   => 'allin_ref_code',
				'meta_value' => $code,
			)
		);

		return $found ? (int) $found[0] : 0;
	}

	/**
	 * Who referred a user.
	 *
	 * @param int $user_id User.
	 * @return int
	 */
	public static function referrer( $user_id ) {
		return (int) get_user_meta( (int) $user_id, 'allin_referred_by', true );
	}

	/**
	 * Invite URL.
	 *
	 * @param int $user_id User.
	 * @return string
	 */
	public static function link( $user_id ) {
		$code = self::code( $user_id );

		return $code ? add_query_arg( 'ref', $code, home_url( '/' ) ) : '';
	}

	/**
	 * Remember ?ref= in a cookie so it survives until the visitor registers.
	 */
	public static function capture_code() {
		if ( empty( $_GET['ref'] ) || is_user_logged_in() ) {
			return;
		}

		$owner = self::owner_of( sanitize_text_field( wp_unslash( $_GET['ref'] ) ) );

		if ( ! $owner ) {
			return;
		}

		setcookie(
			self::COOKIE,
			(string) $owner,
			array(
				'expires'  => time() + 30 * DAY_IN_SECONDS,
				'path'     => COOKIEPATH ? COOKIEPATH : '/',
				'domain'   => COOKIE_DOMAIN,
				'secure'   => is_ssl(),
				'httponly' => true,
				'samesite' => 'Lax',
			)
		);
	}

	/**
	 * Bind once, at registration.
	 *
	 * @param int $user_id New user.
	 */
	public static function bind_on_register( $user_id ) {
		if ( self::referrer( $user_id ) ) {
			return;
		}

		$owner = isset( $_COOKIE[ self::COOKIE ] ) ? (int) $_COOKIE[ self::COOKIE ] : 0;

		if ( ! $owner && ! empty( $_POST['allin_ref'] ) ) {
			$owner = self::owner_of( sanitize_text_field( wp_unslash( $_POST['allin_ref'] ) ) );
		}

		if ( ! $owner || $owner === (int) $user_id || ! get_user_by( 'id', $owner ) ) {
			return;
		}

		// A closed loop (A refers B, B refers A) would let two accounts farm
		// each other's purchases; walk the chain before binding.
		$cursor  = $owner;
		$visited = array( (int) $user_id );

		while ( $cursor ) {
			if ( in_array( $cursor, $visited, true ) ) {
				return;
			}

			$visited[] = $cursor;
			$cursor    = self::referrer( $cursor );
		}

		update_user_meta( $user_id, 'allin_referred_by', $owner );
		update_user_meta( $user_id, 'allin_referred_at', current_time( 'mysql' ) );

		$count = (int) get_user_meta( $owner, 'allin_ref_count', true );
		update_user_meta( $owner, 'allin_ref_count', $count + 1 );

		do_action( 'allin_pro_referral_bound', $user_id, $owner );
	}

	/**
	 * Commission rates, as fractions.
	 *
	 * @return array{level1:float,level2:float}
	 */
	public static function rates() {
		$settings = AllinPro_Settings::instance();

		return array(
			'level1' => max( 0, min( 0.5, (float) $settings->get( 'commission_rate', 0.1 ) ) ),
			'level2' => max( 0, min( 0.3, (float) $settings->get( 'commission_rate_2', 0 ) ) ),
		);
	}

	/**
	 * Pay commission for a paid order.
	 *
	 * @param int   $order_id Order.
	 * @param array $order    Order row.
	 */
	public static function commission( $order_id, $order ) {
		if ( (float) get_post_meta( $order_id, '_allin_recharge_amount', true ) > 0 ) {
			return; // Top-ups do not pay commission.
		}

		$buyer = (int) ( $order['user_id'] ?? 0 );
		$no    = (string) ( $order['no'] ?? '' );
		$total = (float) ( $order['amount'] ?? 0 );

		if ( ! $buyer || '' === $no || $total <= 0 ) {
			return;
		}

		$rates  = self::rates();
		$paid   = array();
		$cursor = self::referrer( $buyer );
		$level  = 1;

		while ( $cursor && $level <= 2 ) {
			$rate = 1 === $level ? $rates['level1'] : $rates['level2'];

			if ( $rate > 0 ) {
				$amount = round( $total * $rate, 2 );

				if ( $amount > 0 ) {
					$result = AllinPro_Balance::credit(
						$cursor,
						$amount,
						'commission',
						$no . ':' . $level,
						sprintf( /* translators: 1: level, 2: order number. */ __( '推广佣金（%1$d 级）· 订单 %2$s', 'allin-pro' ), $level, $no )
					);

					if ( ! is_wp_error( $result ) ) {
						$paid[] = array( 'user_id' => $cursor, 'level' => $level, 'amount' => $amount );
						$earned = (float) get_user_meta( $cursor, 'allin_commission_total', true );
						update_user_meta( $cursor, 'allin_commission_total', round( $earned + $amount, 2 ) );
					}
				}
			}

			$cursor = self::referrer( $cursor );
			$level++;
		}

		if ( $paid ) {
			update_post_meta( $order_id, '_allin_commission', $paid );

			/**
			 * Commission was credited.
			 *
			 * @param int   $order_id Order.
			 * @param array $paid     Rows of user_id, level, amount.
			 */
			do_action( 'allin_pro_commission_paid', $order_id, $paid );
		}
	}

	/**
	 * Promotion page: link, numbers, withdrawal form.
	 *
	 * @return string
	 */
	public static function render_invite() {
		if ( ! is_user_logged_in() ) {
			return sprintf(
				'<p class="allin-note">%s <a href="%s">%s</a></p>',
				esc_html__( '登录后可以查看推广链接与佣金。', 'allin-pro' ),
				esc_url( wp_login_url( get_permalink() ) ),
				esc_html__( '去登录', 'allin-pro' )
			);
		}

		$uid    = get_current_user_id();
		$link   = self::link( $uid );
		$count  = (int) get_user_meta( $uid, 'allin_ref_count', true );
		$earned = (float) get_user_meta( $uid, 'allin_commission_total', true );
		$bal    = AllinPro_Balance::balance( $uid );
		$rates  = self::rates();

		ob_start();
		?>
		<div class="allin-card">
			<div class="allin-stats">
				<div><span><?php esc_html_e( '已邀请', 'allin-pro' ); ?></span><strong><?php echo esc_html( (string) $count ); ?></strong></div>
				<div><span><?php esc_html_e( '累计佣金', 'allin-pro' ); ?></span><strong>¥<?php echo esc_html( number_format( $earned, 2 ) ); ?></strong></div>
				<div><span><?php esc_html_e( '可提现余额', 'allin-pro' ); ?></span><strong>¥<?php echo esc_html( number_format( $bal, 2 ) ); ?></strong></div>
			</div>

			<label class="allin-field">
				<span><?php esc_html_e( '你的专属推广链接', 'allin-pro' ); ?></span>
				<input type="text" readonly value="<?php echo esc_attr( $link ); ?>" data-allin-copy>
			</label>

			<p class="allin-note">
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: first-level rate, 2: second-level rate. */
						__( '好友通过该链接注册后，其消费你可得 %1$s；其邀请的用户消费你可得 %2$s。充值订单不计佣金。', 'allin-pro' ),
						number_format( $rates['level1'] * 100, 0 ) . '%',
						number_format( $rates['level2'] * 100, 0 ) . '%'
					)
				);
				?>
			</p>

			<p><button type="button" class="allin-btn" data-allin-copy-btn><?php esc_html_e( '复制链接', 'allin-pro' ); ?></button></p>
		</div>

		<?php echo AllinPro_Withdraw::render_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in the method. ?>
		<?php echo AllinPro_Withdraw::render_history(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

		<div class="allin-card">
			<h3 class="allin-h3"><?php esc_html_e( '最近佣金', 'allin-pro' ); ?></h3>
			<?php
			$rows = array_filter(
				AllinPro_Balance::entries( $uid, 30 ),
				static function ( $e ) {
					return 'commission' === $e['type'];
				}
			);
			?>
			<?php if ( $rows ) : ?>
				<table class="allin-ledger">
					<tbody>
					<?php foreach ( $rows as $row ) : ?>
						<tr>
							<td><?php echo esc_html( $row['created_at'] ); ?></td>
							<td><?php echo esc_html( $row['note'] ); ?></td>
							<td class="is-in">+<?php echo esc_html( number_format( $row['delta'], 2 ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p class="allin-note"><?php esc_html_e( '还没有佣金，把链接分享出去吧。', 'allin-pro' ); ?></p>
			<?php endif; ?>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Link the promotion page from the theme's user sidebar.
	 *
	 * @param array $links url => label.
	 * @return array
	 */
	public static function quick_link( $links ) {
		$page = get_page_by_path( 'invite' );

		if ( $page ) {
			$links[ get_permalink( $page ) ] = __( '推广中心 · 佣金提现', 'allin-pro' );
		}

		return $links;
	}

	/**
	 * REST: own referral summary.
	 */
	public static function routes() {
		register_rest_route(
			'allin/v1',
			'/referral',
			array(
				'methods'             => 'GET',
				'permission_callback' => static function () {
					return is_user_logged_in();
				},
				'callback'            => static function () {
					$uid = get_current_user_id();

					return rest_ensure_response(
						array(
							'code'     => self::code( $uid ),
							'link'     => self::link( $uid ),
							'invited'  => (int) get_user_meta( $uid, 'allin_ref_count', true ),
							'earned'   => (float) get_user_meta( $uid, 'allin_commission_total', true ),
							'balance'  => AllinPro_Balance::balance( $uid ),
							'rates'    => self::rates(),
							'referrer' => self::referrer( $uid ),
						)
					);
				},
			)
		);
	}
}
