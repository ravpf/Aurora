<?php
/**
 * Payment adapter contract.
 *
 * Every gateway — real or simulated — answers the same four questions, so the
 * checkout code never learns which provider it is talking to:
 *
 *   create( $order )   → how the buyer pays (redirect, QR, or inline form)
 *   query( $order )    → did it go through
 *   refund( $refund )  → money back
 *   verify( $request ) → is this notification really from the provider
 *
 * A real adapter and its sandbox twin are interchangeable: `is_sandbox()` is
 * what the UI and the logs use to say so out loud.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

abstract class AllinPro_Pay_Adapter {

	/**
	 * Machine name, also the URL segment: wechat, alipay, payjs…
	 *
	 * @return string
	 */
	abstract public function id();

	/**
	 * Human name.
	 *
	 * @return string
	 */
	abstract public function title();

	/**
	 * Whether this adapter fakes the network.
	 *
	 * @return bool
	 */
	abstract public function is_sandbox();

	/**
	 * Start a payment.
	 *
	 * @param array $order Order row from the site's ledger.
	 * @return array|WP_Error {
	 *     @type string $type    redirect|qrcode|form
	 *     @type string $url     For redirect.
	 *     @type string $payload For qrcode/form.
	 *     @type string $txn     Our transaction reference.
	 * }
	 */
	abstract public function create( $order );

	/**
	 * Ask the provider what happened.
	 *
	 * @param array $order Order row.
	 * @return array|WP_Error { @type string $status paid|pending|closed }
	 */
	abstract public function query( $order );

	/**
	 * Verify an incoming notification.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */
	abstract public function verify( $request );

	/**
	 * Read the notification body into one shape.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array { @type string $order_no, @type float $amount, @type string $txn, @type string $status }
	 */
	abstract public function parse( $request );

	/**
	 * Refund, in the provider's terms.
	 *
	 * @param array $refund Refund row.
	 * @return array|WP_Error { @type string $status, @type string $refund_no }
	 */
	public function refund( $refund ) {
		return new WP_Error( 'allin_pay_unsupported', __( '该通道不支持退款。', 'allin-pro' ) );
	}

	/**
	 * Does this adapter need credentials before it can run for real?
	 *
	 * @return bool
	 */
	public function is_configured() {
		return $this->is_sandbox();
	}
}
