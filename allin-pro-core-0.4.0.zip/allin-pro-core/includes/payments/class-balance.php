<?php
/**
 * Balance: one account row per user, one append-only ledger.
 *
 * Money is the one place where "read, decide, write" is not good enough: two
 * simultaneous debits would both see enough balance and both succeed. So the
 * account row is the source of truth and every debit is a single conditional
 * UPDATE that the database resolves atomically. The ledger is the audit trail.
 *
 * Every movement carries a `ref` — an order number, a manual adjustment key —
 * and (user_id, ref, type) is UNIQUE, which is what makes a replayed callback
 * harmless.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

class AllinPro_Balance {

	/**
	 * Account table.
	 *
	 * @return string
	 */
	public static function accounts_table() {
		global $wpdb;

		return $wpdb->prefix . 'allin_balance_accounts';
	}

	/**
	 * Ledger table.
	 *
	 * @return string
	 */
	public static function ledger_table() {
		global $wpdb;

		return $wpdb->prefix . 'allin_balance_ledger';
	}

	/**
	 * Current balance. 0.00 for anyone who never had one.
	 *
	 * @param int $user_id User.
	 * @return float
	 */
	public static function balance( $user_id ) {
		global $wpdb;

		$user_id = (int) $user_id;

		if ( $user_id <= 0 ) {
			return 0.0;
		}

		$value = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT balance FROM ' . self::accounts_table() . ' WHERE user_id = %d',
				$user_id
			)
		);

		return null === $value ? 0.0 : round( (float) $value, 2 );
	}

	/**
	 * Add money.
	 *
	 * @param int    $user_id User.
	 * @param float  $amount  Positive amount.
	 * @param string $type    recharge|refund|commission|adjust.
	 * @param string $ref     Idempotency key.
	 * @param string $note    Human note.
	 * @return float|WP_Error New balance.
	 */
	public static function credit( $user_id, $amount, $type = 'adjust', $ref = '', $note = '' ) {
		return self::move( $user_id, abs( (float) $amount ), $type, $ref, $note );
	}

	/**
	 * Take money out. Refuses to go below zero.
	 *
	 * @param int    $user_id User.
	 * @param float  $amount  Positive amount.
	 * @param string $type    purchase|withdraw|adjust.
	 * @param string $ref     Idempotency key.
	 * @param string $note    Human note.
	 * @return float|WP_Error New balance.
	 */
	public static function debit( $user_id, $amount, $type = 'purchase', $ref = '', $note = '' ) {
		if ( self::balance( $user_id ) < round( (float) $amount, 2 ) ) {
			return new WP_Error( 'allin_balance_low', __( '余额不足。', 'allin-pro' ) );
		}

		return self::move( $user_id, -abs( (float) $amount ), $type, $ref, $note );
	}

	/**
	 * Move money in either direction.
	 *
	 * @param int    $user_id User.
	 * @param float  $delta   Signed amount.
	 * @param string $type    Movement type.
	 * @param string $ref     Idempotency key.
	 * @param string $note    Note.
	 * @return float|WP_Error New balance.
	 */
	public static function move( $user_id, $delta, $type, $ref = '', $note = '' ) {
		global $wpdb;

		$user_id = (int) $user_id;
		$delta   = round( (float) $delta, 2 );
		$type    = sanitize_key( $type ) ?: 'adjust';
		$ref     = substr( sanitize_text_field( (string) $ref ), 0, 64 );
		$note    = substr( sanitize_text_field( (string) $note ), 0, 191 );

		if ( $user_id <= 0 || 0.0 === $delta ) {
			return new WP_Error( 'allin_balance_invalid', __( '金额或用户无效。', 'allin-pro' ) );
		}

		// Replay guard: the same ref may only move money once per type.
		if ( '' !== $ref ) {
			$seen = $wpdb->get_var(
				$wpdb->prepare(
					'SELECT id FROM ' . self::ledger_table() . ' WHERE user_id = %d AND ref = %s AND type = %s',
					$user_id,
					$ref,
					$type
				)
			);

			if ( $seen ) {
				return self::balance( $user_id );
			}
		}

		$now = current_time( 'mysql' );

		$wpdb->query(
			$wpdb->prepare(
				'INSERT INTO ' . self::accounts_table() . ' (user_id, balance, updated_at) VALUES (%d, 0, %s)
				 ON DUPLICATE KEY UPDATE user_id = user_id',
				$user_id,
				$now
			)
		);

		if ( $delta > 0 ) {
			$ok = $wpdb->query(
				$wpdb->prepare(
					'UPDATE ' . self::accounts_table() . ' SET balance = balance + %f, updated_at = %s WHERE user_id = %d',
					$delta,
					$now,
					$user_id
				)
			);
		} else {
			// Atomic guard: the row is only updated while it still covers the
			// spend, so two concurrent debits cannot both pass the check.
			$ok = $wpdb->query(
				$wpdb->prepare(
					'UPDATE ' . self::accounts_table() . ' SET balance = balance - %f, updated_at = %s
					 WHERE user_id = %d AND balance >= %f',
					abs( $delta ),
					$now,
					$user_id,
					abs( $delta )
				)
			);

			if ( ! $ok ) {
				return new WP_Error( 'allin_balance_low', __( '余额不足。', 'allin-pro' ) );
			}
		}

		if ( false === $ok ) {
			return new WP_Error( 'allin_balance_db', __( '余额写入失败。', 'allin-pro' ) );
		}

		$after = self::balance( $user_id );

		$inserted = $wpdb->insert(
			self::ledger_table(),
			array(
				'user_id'       => $user_id,
				'delta'         => $delta,
				'type'          => $type,
				'ref'           => $ref,
				'note'          => $note,
				'balance_after' => $after,
				'created_at'    => $now,
			),
			array( '%d', '%f', '%s', '%s', '%s', '%f', '%s' )
		);

		// Lost the race on the unique key: undo the account change and report the
		// balance as it stands. Without this the account and the ledger disagree.
		if ( ! $inserted ) {
			$wpdb->query(
				$wpdb->prepare(
					'UPDATE ' . self::accounts_table() . ' SET balance = balance - %f WHERE user_id = %d',
					$delta,
					$user_id
				)
			);

			return self::balance( $user_id );
		}

		/**
		 * A balance movement happened.
		 *
		 * @param int    $user_id User.
		 * @param float  $delta   Signed amount.
		 * @param string $type    Movement type.
		 * @param float  $after   Balance afterwards.
		 */
		do_action( 'allin_pro_balance_moved', $user_id, $delta, $type, $after );

		return $after;
	}

	/**
	 * Recent movements.
	 *
	 * @param int $user_id User.
	 * @param int $limit   Rows.
	 * @return array
	 */
	public static function entries( $user_id, $limit = 20 ) {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT delta, type, ref, note, balance_after, created_at FROM ' . self::ledger_table() .
				' WHERE user_id = %d ORDER BY id DESC LIMIT %d',
				(int) $user_id,
				max( 1, min( 100, (int) $limit ) )
			),
			ARRAY_A
		);

		return array_map(
			static function ( $row ) {
				$row['delta']         = (float) $row['delta'];
				$row['balance_after'] = (float) $row['balance_after'];

				return $row;
			},
			$rows ?: array()
		);
	}

	/**
	 * Hook up: recharge credit, balance gateway, REST, profile display.
	 */
	public static function register() {
		add_action( 'aurora_order_paid', array( __CLASS__, 'on_order_paid' ), 5, 2 );
		add_filter( 'aurora_payment_gateways', array( __CLASS__, 'add_gateway' ) );
		add_action( 'aurora_checkout_created', array( __CLASS__, 'pay_with_balance' ), 5, 2 );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			WP_CLI::add_command( 'allin balance', 'AllinPro_Balance_CLI' );
		}
	}

	/**
	 * A paid recharge order credits the account, once.
	 *
	 * @param int   $order_id Order.
	 * @param array $order    Order row.
	 */
	public static function on_order_paid( $order_id, $order ) {
		$amount = (float) get_post_meta( $order_id, '_allin_recharge_amount', true );

		if ( $amount <= 0 ) {
			return;
		}

		$user_id = (int) ( $order['user_id'] ?? 0 );

		if ( $user_id <= 0 ) {
			return;
		}

		AllinPro_Balance::credit( $user_id, $amount, 'recharge', (string) $order['no'], __( '余额充值', 'allin-pro' ) );
	}

	/**
	 * Offer "余额支付" when the visitor is logged in.
	 *
	 * @param array $gateways Gateways.
	 * @return array
	 */
	public static function add_gateway( $gateways ) {
		$gateways['balance'] = array(
			'id'      => 'balance',
			'title'   => __( '余额支付', 'allin-pro' ),
			'desc'    => sprintf(
				/* translators: %s: current balance. */
				__( '当前余额 ¥%s，余额不足时无法完成支付。', 'allin-pro' ),
				number_format( self::balance( get_current_user_id() ), 2 )
			),
			'enabled' => is_user_logged_in(),
			'ready'   => is_user_logged_in(),
		);

		return $gateways;
	}

	/**
	 * Complete an order from the balance, or cancel it cleanly.
	 *
	 * @param int    $order_id Order.
	 * @param string $gateway  Gateway.
	 */
	public static function pay_with_balance( $order_id, $gateway ) {
		if ( 'balance' !== $gateway ) {
			return;
		}

		$order = function_exists( 'aurora_get_order' ) ? aurora_get_order( $order_id ) : array();

		if ( empty( $order['no'] ) ) {
			return;
		}

		$user_id = (int) ( $order['user_id'] ?? 0 );
		$amount  = (float) ( $order['amount'] ?? 0 );

		$result = self::debit( $user_id, $amount, 'purchase', (string) $order['no'], __( '余额支付', 'allin-pro' ) );

		if ( is_wp_error( $result ) ) {
			update_post_meta( $order_id, '_aurora_status', 'cancelled' );
			allin_pro_log( 'balance', 'insufficient for order ' . $order['no'] );

			wp_safe_redirect( add_query_arg( 'aurora_msg', 'balance_low', aurora_user_page_url() ) );
			exit;
		}

		aurora_mark_order_paid( $order_id, 'balance:' . $order['no'] );
		allin_pro_log( 'balance', 'paid order ' . $order['no'] );

		wp_safe_redirect( add_query_arg( 'order', $order_id, aurora_user_page_url() ) );
		exit;
	}

	/**
	 * REST: own balance, and an admin adjustment.
	 */
	public static function routes() {
		register_rest_route(
			'allin/v1',
			'/balance',
			array(
				'methods'             => 'GET',
				'permission_callback' => static function () {
					return is_user_logged_in();
				},
				'callback'            => static function () {
					return rest_ensure_response(
						array(
							'balance' => self::balance( get_current_user_id() ),
							'entries' => self::entries( get_current_user_id(), 20 ),
						)
					);
				},
			)
		);

		register_rest_route(
			'allin/v1',
			'/balance/adjust',
			array(
				'methods'             => 'POST',
				'permission_callback' => static function () {
					return current_user_can( 'manage_options' );
				},
				'callback'            => static function ( WP_REST_Request $request ) {
					$user   = (int) $request->get_param( 'user_id' );
					$amount = (float) $request->get_param( 'amount' );
					$note   = (string) $request->get_param( 'note' );

					if ( $amount > 0 ) {
						$result = self::credit( $user, $amount, 'adjust', 'adj_' . wp_generate_password( 8, false, false ), $note );
					} else {
						$result = self::debit( $user, abs( $amount ), 'adjust', 'adj_' . wp_generate_password( 8, false, false ), $note );
					}

					if ( is_wp_error( $result ) ) {
						return new WP_REST_Response( array( 'error' => $result->get_error_code() ), 400 );
					}

					return rest_ensure_response( array( 'balance' => $result ) );
				},
			)
		);
	}
}

/**
 * `wp allin balance` — an operator's way to add or remove money without SQL.
 */
class AllinPro_Balance_CLI {

	/**
	 * Show an account.
	 *
	 * ## OPTIONS
	 *
	 * <user>
	 * : User id, login or email.
	 *
	 * @param array $args Arguments.
	 */
	public function get( $args ) {
		$user = get_user_by( 'id', (int) $args[0] ) ?: get_user_by( 'login', $args[0] ) ?: get_user_by( 'email', $args[0] );

		if ( ! $user ) {
			WP_CLI::error( '用户不存在。' );
		}

		WP_CLI::line( sprintf( '%s 余额: ¥%s', $user->user_login, number_format( AllinPro_Balance::balance( $user->ID ), 2 ) ) );

		foreach ( AllinPro_Balance::entries( $user->ID, 10 ) as $entry ) {
			WP_CLI::line( sprintf( '  %s %+0.2f %-9s %s', $entry['created_at'], $entry['delta'], $entry['type'], $entry['note'] ) );
		}
	}

	/**
	 * Add money.
	 *
	 * ## OPTIONS
	 *
	 * <user>
	 * : User id, login or email.
	 *
	 * <amount>
	 * : Amount.
	 *
	 * [--note=<note>]
	 * : Why.
	 *
	 * @param array $args       Arguments.
	 * @param array $assoc_args Flags.
	 */
	public function credit( $args, $assoc_args ) {
		$user = get_user_by( 'id', (int) $args[0] ) ?: get_user_by( 'login', $args[0] ) ?: get_user_by( 'email', $args[0] );

		if ( ! $user ) {
			WP_CLI::error( '用户不存在。' );
		}

		$result = AllinPro_Balance::credit( $user->ID, (float) $args[1], 'adjust', 'cli_' . wp_generate_password( 8, false, false ), $assoc_args['note'] ?? '' );

		if ( is_wp_error( $result ) ) {
			WP_CLI::error( $result->get_error_message() );
		}

		WP_CLI::success( sprintf( '余额: ¥%0.2f', $result ) );
	}
}
