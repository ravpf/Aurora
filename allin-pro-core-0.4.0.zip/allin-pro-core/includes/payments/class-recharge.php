<?php
/**
 * Recharge: turn a paid order into balance.
 *
 * The checkout itself is not reimplemented here — a recharge is an ordinary
 * order with a marker meta, created through the site's own `aurora_create_order()`
 * and paid through whichever gateway the buyer picks. When that order is paid,
 * `AllinPro_Balance::on_order_paid()` credits the account once, keyed by the
 * order number.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

class AllinPro_Recharge {

	/**
	 * Hook up.
	 */
	public static function register() {
		add_shortcode( 'allin_recharge', array( __CLASS__, 'render_form' ) );
		add_shortcode( 'allin_balance', array( __CLASS__, 'render_balance' ) );
		add_action( 'admin_post_allin_recharge', array( __CLASS__, 'handle' ) );
	}

	/**
	 * Preset amounts.
	 *
	 * @return array
	 */
	public static function presets() {
		$raw = (string) AllinPro_Settings::instance()->get( 'recharge_presets', '10,30,50,100,200' );
		$out = array_filter( array_map( 'floatval', array_map( 'trim', explode( ',', $raw ) ) ) );

		return $out ?: array( 10, 30, 50, 100 );
	}

	/**
	 * Gateways a recharge may use.
	 *
	 * "余额支付" is excluded on purpose: paying a recharge with the balance it
	 * is meant to top up is a loop, not a payment.
	 *
	 * @return array
	 */
	public static function gateways() {
		$gateways = function_exists( 'aurora_available_gateways' ) ? aurora_available_gateways() : array();

		unset( $gateways['balance'] );

		return $gateways;
	}

	/**
	 * Recharge form.
	 *
	 * @return string
	 */
	public static function render_form() {
		if ( ! is_user_logged_in() ) {
			return sprintf(
				'<p class="allin-note">%s <a href="%s">%s</a></p>',
				esc_html__( '登录后可以为账户充值。', 'allin-pro' ),
				esc_url( wp_login_url( get_permalink() ) ),
				esc_html__( '去登录', 'allin-pro' )
			);
		}

		$presets  = self::presets();
		$gateways = self::gateways();
		$balance  = AllinPro_Balance::balance( get_current_user_id() );

		ob_start();
		?>
		<div class="allin-card allin-recharge">
			<div class="allin-balance-line">
				<span><?php esc_html_e( '当前余额', 'allin-pro' ); ?></span>
				<strong>¥<?php echo esc_html( number_format( $balance, 2 ) ); ?></strong>
			</div>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="allin_recharge">
				<?php wp_nonce_field( 'allin_recharge' ); ?>

				<fieldset class="allin-amounts">
					<legend><?php esc_html_e( '充值金额', 'allin-pro' ); ?></legend>
					<?php foreach ( $presets as $preset ) : ?>
						<label class="allin-amount">
							<input type="radio" name="amount" value="<?php echo esc_attr( $preset ); ?>"
								<?php checked( $preset, $presets[0] ); ?>>
							<span>¥<?php echo esc_html( number_format( $preset, 0 ) ); ?></span>
						</label>
					<?php endforeach; ?>
					<label class="allin-amount allin-amount--custom">
						<input type="number" name="custom_amount" min="1" max="50000" step="0.01"
							placeholder="<?php esc_attr_e( '其他金额', 'allin-pro' ); ?>">
					</label>
				</fieldset>

				<?php if ( $gateways ) : ?>
					<label class="allin-field">
						<span><?php esc_html_e( '支付方式', 'allin-pro' ); ?></span>
						<select name="gateway">
							<?php foreach ( $gateways as $id => $gw ) : ?>
								<option value="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $gw['title'] ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
				<?php endif; ?>

				<button type="submit" class="allin-btn"><?php esc_html_e( '去支付', 'allin-pro' ); ?></button>
				<p class="allin-note"><?php esc_html_e( '充值到账后可用于余额支付。沙箱环境下不会产生真实扣款。', 'allin-pro' ); ?></p>
			</form>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Balance + recent movements.
	 *
	 * @return string
	 */
	public static function render_balance() {
		if ( ! is_user_logged_in() ) {
			return '';
		}

		$user_id = get_current_user_id();
		$balance = AllinPro_Balance::balance( $user_id );
		$entries = AllinPro_Balance::entries( $user_id, 20 );

		$labels = array(
			'recharge'   => __( '充值', 'allin-pro' ),
			'purchase'   => __( '消费', 'allin-pro' ),
			'refund'     => __( '退款', 'allin-pro' ),
			'commission' => __( '佣金', 'allin-pro' ),
			'withdraw'   => __( '提现', 'allin-pro' ),
			'adjust'     => __( '管理员调整', 'allin-pro' ),
		);

		ob_start();
		?>
		<div class="allin-card">
			<div class="allin-balance-line">
				<span><?php esc_html_e( '账户余额', 'allin-pro' ); ?></span>
				<strong>¥<?php echo esc_html( number_format( $balance, 2 ) ); ?></strong>
			</div>

			<?php if ( $entries ) : ?>
				<table class="allin-ledger">
					<thead>
						<tr>
							<th><?php esc_html_e( '时间', 'allin-pro' ); ?></th>
							<th><?php esc_html_e( '类型', 'allin-pro' ); ?></th>
							<th><?php esc_html_e( '金额', 'allin-pro' ); ?></th>
							<th><?php esc_html_e( '余额', 'allin-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $entries as $entry ) : ?>
							<tr>
								<td><?php echo esc_html( $entry['created_at'] ); ?></td>
								<td><?php echo esc_html( $labels[ $entry['type'] ] ?? $entry['type'] ); ?></td>
								<td class="<?php echo $entry['delta'] >= 0 ? 'is-in' : 'is-out'; ?>">
									<?php echo esc_html( sprintf( '%+0.2f', $entry['delta'] ) ); ?>
								</td>
								<td><?php echo esc_html( number_format( $entry['balance_after'], 2 ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p class="allin-note"><?php esc_html_e( '还没有余额记录。', 'allin-pro' ); ?></p>
			<?php endif; ?>

			<p><a class="allin-btn allin-btn--ghost" href="<?php echo esc_url( home_url( '/recharge' ) ); ?>">
				<?php esc_html_e( '去充值', 'allin-pro' ); ?>
			</a></p>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Create the recharge order and hand it to checkout.
	 */
	public static function handle() {
		if ( ! is_user_logged_in() || ! check_admin_referer( 'allin_recharge' ) ) {
			wp_die( esc_html__( '请求已过期，请重新提交。', 'allin-pro' ), 403 );
		}

		$custom = isset( $_POST['custom_amount'] ) ? (float) $_POST['custom_amount'] : 0;
		$amount = $custom > 0 ? $custom : (float) ( $_POST['amount'] ?? 0 );
		$amount = round( $amount, 2 );

		$gateway  = sanitize_key( wp_unslash( $_POST['gateway'] ?? 'manual' ) );
		$gateways = self::gateways();

		if ( $amount < 1 || $amount > 50000 ) {
			wp_safe_redirect( add_query_arg( 'allin_msg', 'amount', home_url( '/recharge' ) ) );
			exit;
		}

		if ( ! isset( $gateways[ $gateway ] ) ) {
			wp_safe_redirect( add_query_arg( 'allin_msg', 'gateway', home_url( '/recharge' ) ) );
			exit;
		}

		$order_id = aurora_create_order(
			array(
				'user_id' => get_current_user_id(),
				'product' => sprintf( /* translators: %s: amount. */ __( '余额充值 ¥%s', 'allin-pro' ), number_format( $amount, 2 ) ),
				'amount'  => $amount,
				'gateway' => $gateway,
			)
		);

		if ( is_wp_error( $order_id ) ) {
			wp_safe_redirect( add_query_arg( 'allin_msg', 'order', home_url( '/recharge' ) ) );
			exit;
		}

		update_post_meta( $order_id, '_allin_recharge_amount', $amount );

		do_action( 'aurora_checkout_created', $order_id, $gateway );

		// Nothing redirected (manual channel): the order page explains the rest.
		wp_safe_redirect( add_query_arg( 'order', $order_id, aurora_user_page_url() ) );
		exit;
	}
}
