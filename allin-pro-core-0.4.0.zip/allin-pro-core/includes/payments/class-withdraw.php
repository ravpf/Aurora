<?php
/**
 * Withdrawals.
 *
 * Order of operations matters here: the balance is debited **before** the
 * request is stored, so a request can never be submitted twice against the same
 * money. If the debit fails the post is deleted again — a request row must not
 * exist without money already set aside.
 *
 * Rejecting refunds the money with its own idempotency key (wd_<id>), so an
 * approved-then-rejected pair cannot pay out twice.
 *
 * Payout itself is manual: the operator sees the channel and account, sends the
 * money, then marks it done. No provider API is involved, so this works with no
 * merchant credentials at all.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

class AllinPro_Withdraw {

	const CPT = 'allin_withdraw';

	/**
	 * Hook up.
	 */
	public static function register() {
		add_action( 'init', array( __CLASS__, 'post_type' ) );
		add_action( 'admin_post_allin_withdraw_request', array( __CLASS__, 'handle_request' ) );
		add_action( 'admin_post_allin_withdraw_decide', array( __CLASS__, 'handle_decision' ) );
		add_filter( 'manage_' . self::CPT . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . self::CPT . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
		add_action( 'admin_notices', array( __CLASS__, 'admin_notice' ) );
	}

	/**
	 * Private post type: the list is an operator queue, not a public archive.
	 */
	public static function post_type() {
		register_post_type(
			self::CPT,
			array(
				'labels'          => array(
					'name'          => __( '提现申请', 'allin-pro' ),
					'singular_name' => __( '提现申请', 'allin-pro' ),
				),
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => true,
				'menu_icon'       => 'dashicons-money-alt',
				'capability_type' => 'post',
				'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
				'map_meta_cap'    => true,
				'supports'        => array( 'title' ),
			)
		);
	}

	/**
	 * Minimum payout.
	 *
	 * @return float
	 */
	public static function minimum() {
		return max( 1, (float) AllinPro_Settings::instance()->get( 'withdraw_min', 10 ) );
	}

	/**
	 * Request form.
	 *
	 * @return string
	 */
	public static function render_form() {
		if ( ! is_user_logged_in() ) {
			return '';
		}

		$balance = AllinPro_Balance::balance( get_current_user_id() );

		ob_start();
		?>
		<div class="allin-card">
			<h3 class="allin-h3"><?php esc_html_e( '申请提现', 'allin-pro' ); ?></h3>
			<p class="allin-note">
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: balance, 2: minimum. */
						__( '当前可提现 ¥%1$s，单笔最低 ¥%2$s。提交后金额立即从余额扣除，管理员审核打款。', 'allin-pro' ),
						number_format( $balance, 2 ),
						number_format( self::minimum(), 2 )
					)
				);
				?>
			</p>

			<?php if ( $balance >= self::minimum() ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="allin_withdraw_request">
					<?php wp_nonce_field( 'allin_withdraw' ); ?>

					<label class="allin-field">
						<span><?php esc_html_e( '提现金额', 'allin-pro' ); ?></span>
						<input type="number" name="amount" min="<?php echo esc_attr( (string) self::minimum() ); ?>"
							max="<?php echo esc_attr( (string) $balance ); ?>" step="0.01" required>
					</label>

					<label class="allin-field">
						<span><?php esc_html_e( '收款方式', 'allin-pro' ); ?></span>
						<select name="channel">
							<option value="wechat"><?php esc_html_e( '微信', 'allin-pro' ); ?></option>
							<option value="alipay"><?php esc_html_e( '支付宝', 'allin-pro' ); ?></option>
						</select>
					</label>

					<label class="allin-field">
						<span><?php esc_html_e( '收款账号', 'allin-pro' ); ?></span>
						<input type="text" name="account" required maxlength="80"
							placeholder="<?php esc_attr_e( '微信号 / 支付宝账号', 'allin-pro' ); ?>">
					</label>

					<label class="allin-field">
						<span><?php esc_html_e( '真实姓名', 'allin-pro' ); ?></span>
						<input type="text" name="name" maxlength="40" placeholder="<?php esc_attr_e( '选填', 'allin-pro' ); ?>">
					</label>

					<button type="submit" class="allin-btn"><?php esc_html_e( '提交申请', 'allin-pro' ); ?></button>
				</form>
			<?php else : ?>
				<p class="allin-note"><?php esc_html_e( '余额还没达到提现门槛。', 'allin-pro' ); ?></p>
			<?php endif; ?>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * This user's requests.
	 *
	 * @return string
	 */
	public static function render_history() {
		if ( ! is_user_logged_in() ) {
			return '';
		}

		$rows = get_posts(
			array(
				'post_type'      => self::CPT,
				'post_status'    => 'any',
				'author'         => get_current_user_id(),
				'posts_per_page' => 20,
				'no_found_rows'  => true,
			)
		);

		if ( ! $rows ) {
			return '';
		}

		$labels = array(
			'pending'  => __( '待审核', 'allin-pro' ),
			'paid'     => __( '已打款', 'allin-pro' ),
			'rejected' => __( '已驳回', 'allin-pro' ),
		);

		ob_start();
		?>
		<div class="allin-card">
			<h3 class="allin-h3"><?php esc_html_e( '提现记录', 'allin-pro' ); ?></h3>
			<table class="allin-ledger">
				<thead>
					<tr>
						<th><?php esc_html_e( '时间', 'allin-pro' ); ?></th>
						<th><?php esc_html_e( '金额', 'allin-pro' ); ?></th>
						<th><?php esc_html_e( '方式', 'allin-pro' ); ?></th>
						<th><?php esc_html_e( '状态', 'allin-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $rows as $row ) : ?>
						<?php $status = (string) get_post_meta( $row->ID, '_wd_status', true ); ?>
						<tr>
							<td><?php echo esc_html( get_the_date( 'Y-m-d H:i', $row ) ); ?></td>
							<td><?php echo esc_html( '¥' . number_format( (float) get_post_meta( $row->ID, '_wd_amount', true ), 2 ) ); ?></td>
							<td><?php echo esc_html( 'wechat' === get_post_meta( $row->ID, '_wd_channel', true ) ? __( '微信', 'allin-pro' ) : __( '支付宝', 'allin-pro' ) ); ?></td>
							<td><?php echo esc_html( $labels[ $status ] ?? $status ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Create a request: debit first, then store.
	 */
	public static function handle_request() {
		if ( ! is_user_logged_in() || ! check_admin_referer( 'allin_withdraw' ) ) {
			wp_die( esc_html__( '请求已过期，请重新提交。', 'allin-pro' ), 403 );
		}

		$uid     = get_current_user_id();
		$amount  = round( (float) ( $_POST['amount'] ?? 0 ), 2 );
		$channel = 'alipay' === ( $_POST['channel'] ?? '' ) ? 'alipay' : 'wechat';
		$account = sanitize_text_field( wp_unslash( $_POST['account'] ?? '' ) );
		$name    = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
		$back    = add_query_arg( 'allin_msg', 'withdraw', home_url( '/invite' ) );

		if ( $amount < self::minimum() || $amount > 50000 || '' === $account ) {
			wp_safe_redirect( add_query_arg( 'allin_msg', 'withdraw_invalid', home_url( '/invite' ) ) );
			exit;
		}

		if ( AllinPro_Balance::balance( $uid ) < $amount ) {
			wp_safe_redirect( add_query_arg( 'allin_msg', 'withdraw_low', home_url( '/invite' ) ) );
			exit;
		}

		$post_id = wp_insert_post(
			array(
				'post_type'   => self::CPT,
				'post_status' => 'publish',
				'post_title'  => sprintf( '提现 ¥%s · %s', number_format( $amount, 2 ), wp_get_current_user()->user_login ),
				'post_author' => $uid,
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			wp_safe_redirect( $back );
			exit;
		}

		$ref    = 'wd_' . $post_id;
		$result = AllinPro_Balance::debit( $uid, $amount, 'withdraw', $ref, __( '提现申请', 'allin-pro' ) );

		if ( is_wp_error( $result ) ) {
			wp_delete_post( $post_id, true );
			wp_safe_redirect( add_query_arg( 'allin_msg', 'withdraw_low', home_url( '/invite' ) ) );
			exit;
		}

		update_post_meta( $post_id, '_wd_user', $uid );
		update_post_meta( $post_id, '_wd_amount', $amount );
		update_post_meta( $post_id, '_wd_channel', $channel );
		update_post_meta( $post_id, '_wd_account', $account );
		update_post_meta( $post_id, '_wd_name', $name );
		update_post_meta( $post_id, '_wd_status', 'pending' );
		update_post_meta( $post_id, '_wd_ref', $ref );

		allin_pro_log( 'withdraw', sprintf( 'request #%d ¥%s by user %d', $post_id, $amount, $uid ) );

		wp_safe_redirect( add_query_arg( 'allin_msg', 'withdraw_ok', home_url( '/invite' ) ) );
		exit;
	}

	/**
	 * Approve or reject.
	 */
	public static function handle_decision() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '没有权限。', 'allin-pro' ), 403 );
		}

		$post_id = (int) ( $_POST['id'] ?? 0 );
		$decision = sanitize_key( $_POST['decision'] ?? '' );

		if ( ! $post_id || ! check_admin_referer( 'allin_wd_' . $post_id ) ) {
			wp_die( esc_html__( '请求已过期。', 'allin-pro' ), 403 );
		}

		$status = (string) get_post_meta( $post_id, '_wd_status', true );

		if ( 'pending' !== $status ) {
			wp_safe_redirect( add_query_arg( 'allin_wd', 'already', admin_url( 'edit.php?post_type=' . self::CPT ) ) );
			exit;
		}

		if ( 'pay' === $decision ) {
			update_post_meta( $post_id, '_wd_status', 'paid' );
			update_post_meta( $post_id, '_wd_paid_at', current_time( 'mysql' ) );
		} else {
			$uid    = (int) get_post_meta( $post_id, '_wd_user', true );
			$amount = (float) get_post_meta( $post_id, '_wd_amount', true );

			AllinPro_Balance::credit(
				$uid,
				$amount,
				'refund',
				'wd_' . $post_id,
				sprintf( /* translators: %d: request id. */ __( '提现驳回退回 #%d', 'allin-pro' ), $post_id )
			);

			update_post_meta( $post_id, '_wd_status', 'rejected' );
			update_post_meta( $post_id, '_wd_rejected_at', current_time( 'mysql' ) );
		}

		wp_safe_redirect( add_query_arg( 'allin_wd', 'pay' === $decision ? 'paid' : 'rejected', admin_url( 'edit.php?post_type=' . self::CPT ) ) );
		exit;
	}

	/**
	 * Admin columns.
	 *
	 * @param array $columns Columns.
	 * @return array
	 */
	public static function columns( $columns ) {
		return array(
			'cb'       => $columns['cb'],
			'title'    => __( '申请', 'allin-pro' ),
			'wd_user'  => __( '用户', 'allin-pro' ),
			'wd_amount' => __( '金额', 'allin-pro' ),
			'wd_channel' => __( '方式 / 账号', 'allin-pro' ),
			'wd_status' => __( '状态', 'allin-pro' ),
			'wd_action' => __( '操作', 'allin-pro' ),
		);
	}

	/**
	 * Column content and actions.
	 *
	 * @param string $column  Column.
	 * @param int    $post_id Post.
	 */
	public static function column( $column, $post_id ) {
		$labels = array(
			'pending'  => __( '待审核', 'allin-pro' ),
			'paid'     => __( '已打款', 'allin-pro' ),
			'rejected' => __( '已驳回', 'allin-pro' ),
		);
		$status = (string) get_post_meta( $post_id, '_wd_status', true );

		switch ( $column ) {
			case 'wd_user':
				$user = get_user_by( 'id', (int) get_post_meta( $post_id, '_wd_user', true ) );
				echo esc_html( $user ? $user->user_login : '—' );
				break;

			case 'wd_amount':
				echo esc_html( '¥' . number_format( (float) get_post_meta( $post_id, '_wd_amount', true ), 2 ) );
				break;

			case 'wd_channel':
				echo esc_html( sprintf(
					'%s · %s%s',
					'wechat' === get_post_meta( $post_id, '_wd_channel', true ) ? __( '微信', 'allin-pro' ) : __( '支付宝', 'allin-pro' ),
					(string) get_post_meta( $post_id, '_wd_account', true ),
					get_post_meta( $post_id, '_wd_name', true ) ? ' (' . get_post_meta( $post_id, '_wd_name', true ) . ')' : ''
				) );
				break;

			case 'wd_status':
				echo esc_html( $labels[ $status ] ?? $status );
				break;

			case 'wd_action':
				if ( 'pending' !== $status ) {
					echo '—';
					break;
				}
				foreach ( array( 'pay' => __( '标记已打款', 'allin-pro' ), 'reject' => __( '驳回并退余额', 'allin-pro' ) ) as $decision => $label ) {
					printf(
						'<form method="post" action="%s" style="display:inline;margin-right:6px">%s%s<button type="submit" class="button button-small">%s</button></form>',
						esc_url( admin_url( 'admin-post.php' ) ),
						'<input type="hidden" name="action" value="allin_withdraw_decide">',
						wp_nonce_field( 'allin_wd_' . $post_id, '_wpnonce', true, false ) .
						sprintf( '<input type="hidden" name="id" value="%d"><input type="hidden" name="decision" value="%s">', (int) $post_id, esc_attr( $decision ) ),
						esc_html( $label )
					);
				}
				break;
		}
	}

	/**
	 * Result banner.
	 */
	public static function admin_notice() {
		if ( empty( $_GET['allin_wd'] ) ) {
			return;
		}

		$map = array(
			'paid'     => __( '已标记打款。', 'allin-pro' ),
			'rejected' => __( '已驳回，金额退回余额。', 'allin-pro' ),
			'already'  => __( '该申请已经处理过了。', 'allin-pro' ),
		);
		$key = sanitize_key( wp_unslash( $_GET['allin_wd'] ) );

		if ( isset( $map[ $key ] ) ) {
			printf( '<div class="notice notice-success is-dismissible"><p>%s</p></div>', esc_html( $map[ $key ] ) );
		}
	}
}
