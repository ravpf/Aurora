<?php
/**
 * Payment gateway registry and the sandbox checkout screen.
 *
 * The site already owns the order ledger (`aurora_order` posts, statuses,
 * refunds, entitlements). This module does not touch any of that: it answers
 * "how does the buyer pay" and, when the money is confirmed, calls the ledger's
 * own `aurora_mark_order_paid()`. That keeps one writer for order state.
 *
 * Real vs simulated is a property of the adapter, not a branch in the checkout.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

class AllinPro_Payments {

	/**
	 * Built-in gateway definitions: id => label.
	 *
	 * @return array
	 */
	public static function gateway_catalog() {
		return apply_filters(
			'allin_pro_payment_catalog',
			array(
				'wechat'  => __( '微信支付', 'allin-pro' ),
				'alipay'  => __( '支付宝', 'allin-pro' ),
				'payjs'   => __( 'PayJS', 'allin-pro' ),
				'xunhu'   => __( '迅虎支付', 'allin-pro' ),
				'epay'    => __( '易支付', 'allin-pro' ),
				'codepay' => __( '码支付', 'allin-pro' ),
			)
		);
	}

	/**
	 * Enabled gateway ids, in catalog order.
	 *
	 * @return array
	 */
	public static function enabled_ids() {
		$raw = (string) AllinPro_Settings::instance()->get( 'pay_gateways', 'wechat,alipay,payjs,xunhu,epay,codepay' );
		$ids = array_filter( array_map( 'sanitize_key', array_map( 'trim', explode( ',', $raw ) ) ) );

		return array_values( array_intersect( array_keys( self::gateway_catalog() ), $ids ) );
	}

	/**
	 * Adapters, one per enabled gateway.
	 *
	 * A gateway whose credentials are missing is replaced by its sandbox twin —
	 * that swap is the whole adapter contract.
	 *
	 * @return array<string,AllinPro_Pay_Adapter>
	 */
	public static function adapters() {
		$catalog  = self::gateway_catalog();
		$adapters = array();

		foreach ( self::enabled_ids() as $id ) {
			$adapter = apply_filters( 'allin_pro_pay_adapter', null, $id );

			if ( ! $adapter instanceof AllinPro_Pay_Adapter ) {
				$adapter = new AllinPro_Pay_Sandbox( $id, $catalog[ $id ] );
			}

			$adapters[ $id ] = $adapter;
		}

		return $adapters;
	}

	/**
	 * One adapter, or null.
	 *
	 * @param string $id Gateway id.
	 * @return AllinPro_Pay_Adapter|null
	 */
	public static function adapter( $id ) {
		$adapters = self::adapters();

		return $adapters[ $id ] ?? null;
	}

	/**
	 * Hook up.
	 */
	public static function register() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'aurora_checkout_created', array( __CLASS__, 'after_checkout' ), 20, 2 );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_pay_screen' ) );
		add_action( 'admin_post_allin_pay_confirm', array( __CLASS__, 'confirm' ) );
	}

	/**
	 * REST routes.
	 */
	public static function routes() {
		register_rest_route(
			'allin/v1',
			'/pay/gateways',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'callback'            => static function () {
					$out = array();

					foreach ( self::adapters() as $id => $adapter ) {
						$out[] = array(
							'id'       => $id,
							'title'    => $adapter->title(),
							'sandbox'  => $adapter->is_sandbox(),
							'configured' => $adapter->is_configured(),
						);
					}

					return rest_ensure_response( $out );
				},
			)
		);

		register_rest_route(
			'allin/v1',
			'/pay/notify/(?P<gateway>[a-z0-9_-]+)',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => array( __CLASS__, 'notify' ),
			)
		);
	}

	/**
	 * After the ledger created an order, send the buyer to the gateway.
	 *
	 * Runs after the site's own WeChat handler (priority 10) so a real,
	 * configured WeChat payment keeps its existing flow untouched.
	 *
	 * @param int    $order_id Order.
	 * @param string $gateway  Gateway id.
	 */
	public static function after_checkout( $order_id, $gateway ) {
		if ( 'manual' === $gateway ) {
			return;
		}

		$adapter = self::adapter( $gateway );

		if ( ! $adapter || ! $adapter->is_sandbox() ) {
			return; // A real adapter took over already.
		}

		$order = function_exists( 'aurora_get_order' ) ? aurora_get_order( $order_id ) : array();

		if ( empty( $order['id'] ) || 'paid' === ( $order['status'] ?? '' ) ) {
			return;
		}

		$intent = $adapter->create( $order );

		if ( is_wp_error( $intent ) ) {
			allin_pro_log( 'pay', 'intent failed: ' . $intent->get_error_message() );
			return;
		}

		update_post_meta( $order_id, '_allin_pay_gateway', sanitize_key( $gateway ) );
		update_post_meta( $order_id, '_allin_pay_txn', sanitize_text_field( $intent['txn'] ?? '' ) );

		if ( 'redirect' === ( $intent['type'] ?? '' ) && ! empty( $intent['url'] ) ) {
			wp_safe_redirect( $intent['url'] );
			exit;
		}
	}

	/**
	 * Render the sandbox pay screen for ?allin_pay=1.
	 */
	public static function maybe_pay_screen() {
		if ( ! isset( $_GET['allin_pay'], $_GET['order'] ) ) {
			return;
		}

		$order_id = (int) $_GET['order'];
		$gateway  = sanitize_key( wp_unslash( $_GET['gateway'] ?? '' ) );
		$adapter  = self::adapter( $gateway );

		if ( ! $adapter || ! $adapter->is_sandbox() ) {
			wp_die( esc_html__( '支付通道不可用。', 'allin-pro' ), 404 );
		}

		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( add_query_arg( $_GET, home_url( '/' ) ) ) );
			exit;
		}

		$order = function_exists( 'aurora_get_order' ) ? aurora_get_order( $order_id ) : array();
		$uid   = (int) ( $order['user_id'] ?? 0 );

		if ( empty( $order['no'] ) || ( get_current_user_id() !== $uid && ! current_user_can( 'manage_options' ) ) ) {
			wp_die( esc_html__( '订单不存在，或不属于当前账号。', 'allin-pro' ), 404 );
		}

		// A transaction reference has to exist before the buyer confirms:
		// otherwise the ledger records a paid order with no reference, and a
		// later refund cannot be matched to anything.
		$txn = (string) get_post_meta( $order_id, '_allin_pay_txn', true );

		if ( '' === $txn ) {
			$txn = 'sbx_' . $gateway . '_' . wp_generate_password( 10, false, false );
			update_post_meta( $order_id, '_allin_pay_txn', $txn );
			update_post_meta( $order_id, '_allin_pay_gateway', $gateway );
		}

		$amount = number_format( (float) ( $order['amount'] ?? 0 ), 2 );
		$paid   = 'paid' === ( $order['status'] ?? '' );

		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo esc_html( sprintf( '%s · 沙箱支付', $adapter->title() ) ); ?></title>
<style>
  :root { color-scheme: light dark; }
  body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px;
         font: 16px/1.6 -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif;
         background: linear-gradient(160deg, #eef4ff, #f7f7fa 45%, #eaf7f1);
         color: #1d1d1f; }
  .card { width: 100%; max-width: 420px; padding: 30px 28px 26px; border-radius: 20px;
          background: rgba(255,255,255,.82); backdrop-filter: blur(18px);
          box-shadow: 0 18px 50px rgba(0,0,0,.10); }
  .tag { display: inline-block; padding: 3px 10px; border-radius: 999px; font-size: 12px;
         font-weight: 600; color: #0a6b2f; background: #e3f7e9; }
  h1 { margin: 14px 0 4px; font-size: 21px; letter-spacing: -0.01em; }
  .amount { font-size: 34px; font-weight: 700; letter-spacing: -0.02em; margin: 8px 0 2px; }
  .meta { color: #6e6e73; font-size: 13px; }
  .row { display: flex; justify-content: space-between; gap: 12px; padding: 9px 0;
         border-top: 1px solid rgba(0,0,0,.06); font-size: 14px; }
  .row span:last-child { color: #1d1d1f; font-variant-numeric: tabular-nums; }
  form { margin: 18px 0 0; display: grid; gap: 10px; }
  button { padding: 12px 16px; border-radius: 12px; border: 0; font-size: 15px;
           font-weight: 600; cursor: pointer; }
  .ok { background: #0071e3; color: #fff; }
  .ok:hover { background: #0066cc; }
  .no { background: rgba(0,0,0,.06); color: #1d1d1f; }
  .note { margin-top: 14px; font-size: 12px; color: #6e6e73; }
  a { color: #0066cc; }
</style>
</head>
<body>
<div class="card">
	<span class="tag">沙箱模拟 · 不产生真实扣款</span>
	<h1><?php echo esc_html( $adapter->title() ); ?></h1>
	<div class="amount">¥<?php echo esc_html( $amount ); ?></div>
	<div class="meta"><?php echo esc_html( $order['product'] ?? '' ); ?></div>

	<div style="margin-top:18px">
		<div class="row"><span>订单号</span><span><?php echo esc_html( $order['no'] ); ?></span></div>
		<div class="row"><span>状态</span><span><?php echo esc_html( $paid ? '已支付' : '待支付' ); ?></span></div>
		<div class="row"><span>交易号</span><span><?php echo esc_html( $txn ); ?></span></div>
	</div>

	<?php if ( $paid ) : ?>
		<p class="note">这笔订单已经支付完成，无需重复操作。</p>
	<?php else : ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="allin_pay_confirm">
			<input type="hidden" name="order" value="<?php echo esc_attr( (string) $order_id ); ?>">
			<input type="hidden" name="gateway" value="<?php echo esc_attr( $gateway ); ?>">
			<?php wp_nonce_field( 'allin_pay_confirm_' . $order_id ); ?>
			<button class="ok" type="submit" name="result" value="ok">模拟支付成功</button>
			<button class="no" type="submit" name="result" value="fail">模拟支付失败</button>
		</form>
	<?php endif; ?>

	<p class="note">这是演示环境。接入真实商户后，这个页面会被服务商的收银台替代，回调地址为
		<code><?php echo esc_html( rest_url( 'allin/v1/pay/notify/' . $gateway ) ); ?></code></p>
</div>
</body>
</html>
		<?php
		exit;
	}

	/**
	 * Sandbox confirmation.
	 */
	public static function confirm() {
		$order_id = isset( $_POST['order'] ) ? (int) $_POST['order'] : 0;

		if ( ! is_user_logged_in() || ! check_admin_referer( 'allin_pay_confirm_' . $order_id ) ) {
			wp_die( esc_html__( '请求已过期，请重新发起支付。', 'allin-pro' ), 403 );
		}

		$order = function_exists( 'aurora_get_order' ) ? aurora_get_order( $order_id ) : array();
		$uid   = (int) ( $order['user_id'] ?? 0 );

		if ( empty( $order['no'] ) || ( get_current_user_id() !== $uid && ! current_user_can( 'manage_options' ) ) ) {
			wp_die( esc_html__( '订单不存在，或不属于当前账号。', 'allin-pro' ), 404 );
		}

		$failed = ( $_POST['result'] ?? 'ok' ) !== 'ok';

		if ( ! $failed && function_exists( 'aurora_mark_order_paid' ) ) {
			aurora_mark_order_paid( $order_id, (string) get_post_meta( $order_id, '_allin_pay_txn', true ) );
			allin_pro_log( 'pay', 'sandbox paid order ' . $order['no'] );
		}

		$back = function_exists( 'aurora_user_page_url' ) ? add_query_arg( 'order', $order_id, aurora_user_page_url() ) : home_url( '/' );

		wp_safe_redirect( add_query_arg( 'allin_pay_result', $failed ? 'fail' : 'ok', $back ) );
		exit;
	}

	/**
	 * Provider notification.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function notify( $request ) {
		$gateway = sanitize_key( $request['gateway'] );
		$adapter = self::adapter( $gateway );

		if ( ! $adapter ) {
			return new WP_REST_Response( array( 'code' => 'unknown_gateway' ), 404 );
		}

		if ( ! $adapter->verify( $request ) ) {
			allin_pro_log( 'pay', 'notify signature rejected for ' . $gateway );

			return new WP_REST_Response( array( 'code' => 'bad_signature' ), 400 );
		}

		$data = $adapter->parse( $request );

		if ( 'paid' !== $data['status'] ) {
			return new WP_REST_Response( array( 'code' => 'ignored' ), 200 );
		}

		$order_id = self::find_order_by_no( $data['order_no'] );

		if ( ! $order_id ) {
			return new WP_REST_Response( array( 'code' => 'unknown_order' ), 404 );
		}

		$order  = aurora_get_order( $order_id );
		$amount = (float) ( $order['amount'] ?? 0 );

		// The notification's amount is never trusted as the price: it may only
		// confirm the amount the ledger already recorded.
		if ( abs( $amount - (float) $data['amount'] ) > 0.009 ) {
			allin_pro_log( 'pay', 'amount mismatch on ' . $data['order_no'] );

			return new WP_REST_Response( array( 'code' => 'amount_mismatch' ), 400 );
		}

		aurora_mark_order_paid( $order_id, $data['txn'] );
		update_post_meta( $order_id, '_allin_pay_gateway', $gateway );

		return new WP_REST_Response( array( 'code' => 'SUCCESS' ), 200 );
	}

	/**
	 * Order id from its number.
	 *
	 * @param string $no Order number.
	 * @return int
	 */
	public static function find_order_by_no( $no ) {
		$no = trim( (string) $no );

		if ( '' === $no ) {
			return 0;
		}

		$found = get_posts(
			array(
				'post_type'      => 'aurora_order',
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_key'       => '_aurora_order_no',
				'meta_value'     => $no,
				'no_found_rows'  => true,
			)
		);

		return $found ? (int) $found[0] : 0;
	}
}
