<?php
/**
 * Sandbox payment adapters.
 *
 * One simulation, six brands. The point is not to pretend a real Alipay
 * response arrived; it is to let an operator walk the whole path — checkout,
 * intent, "pay", notification, entitlement, refund — with no merchant account,
 * and to swap in the real adapter later without touching the call sites.
 *
 * The simulated notification is signed with the site salt, so the notify
 * endpoint's signature check is exercised rather than skipped.
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

class AllinPro_Pay_Sandbox extends AllinPro_Pay_Adapter {

	/**
	 * Gateway id.
	 *
	 * @var string
	 */
	private $id;

	/**
	 * Gateway label.
	 *
	 * @var string
	 */
	private $label;

	/**
	 * Setup.
	 *
	 * @param string $id    Gateway id.
	 * @param string $label Gateway label.
	 */
	public function __construct( $id, $label ) {
		$this->id    = $id;
		$this->label = $label;
	}

	public function id() {
		return $this->id;
	}

	public function title() {
		return $this->label;
	}

	public function is_sandbox() {
		return true;
	}

	/**
	 * Point at the local confirmation screen instead of a provider page.
	 *
	 * @param array $order Order row.
	 * @return array
	 */
	public function create( $order ) {
		$txn = 'sbx_' . $this->id . '_' . wp_generate_password( 10, false, false );

		return array(
			'type' => 'redirect',
			'url'  => add_query_arg(
				array(
					'allin_pay' => 1,
					'order'     => (int) $order['id'],
					'gateway'   => $this->id,
					'txn'       => $txn,
				),
				home_url( '/' )
			),
			'txn'  => $txn,
		);
	}

	/**
	 * A sandbox payment only moves when the buyer confirmed it.
	 *
	 * @param array $order Order row.
	 * @return array
	 */
	public function query( $order ) {
		$paid = 'paid' === ( $order['status'] ?? '' );

		return array(
			'status'  => $paid ? 'paid' : 'pending',
			'sandbox' => true,
		);
	}

	/**
	 * Signature over gateway|order|amount|txn, keyed with the site salt.
	 *
	 * @param string $order_no Order number.
	 * @param float  $amount   Amount.
	 * @param string $txn      Transaction id.
	 * @return string
	 */
	public function sign( $order_no, $amount, $txn ) {
		return hash_hmac( 'sha256', $this->id . '|' . $order_no . '|' . number_format( (float) $amount, 2, '.', '' ) . '|' . $txn, wp_salt( 'auth' ) );
	}

	/**
	 * Constant-time signature check.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */
	public function verify( $request ) {
		$given = (string) $request->get_header( 'x_allin_signature' );

		if ( '' === $given ) {
			return false;
		}

		$body = $request->get_json_params();
		$body = is_array( $body ) ? $body : array();

		$expected = $this->sign(
			(string) ( $body['order'] ?? '' ),
			(float) ( $body['amount'] ?? 0 ),
			(string) ( $body['txn'] ?? '' )
		);

		return hash_equals( $expected, $given );
	}

	/**
	 * Read the body.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public function parse( $request ) {
		$body = $request->get_json_params();
		$body = is_array( $body ) ? $body : array();

		return array(
			'order_no' => (string) ( $body['order'] ?? '' ),
			'amount'   => (float) ( $body['amount'] ?? 0 ),
			'txn'      => (string) ( $body['txn'] ?? '' ),
			'status'   => 'paid' === ( $body['status'] ?? 'paid' ) ? 'paid' : 'failed',
		);
	}

	/**
	 * Refund without moving money.
	 *
	 * @param array $refund Refund row.
	 * @return array
	 */
	public function refund( $refund ) {
		return array(
			'status'    => 'success',
			'refund_no' => 'sbxr_' . wp_generate_password( 8, false, false ),
			'sandbox'   => true,
		);
	}
}
