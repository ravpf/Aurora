<?php
/**
 * Plugin Name:       Allin Pro Core
 * Plugin URI:        https://example.com/allin-pro
 * Description:       站点业务内核：会员、付费、商城、社区、导航、微信生态。与主题解耦，模块可单独开关；第三方接口全部走适配器，缺密钥时自动降级为沙箱实现。
 * Version:           0.4.0
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            Allin Pro
 * License:           GPL-2.0-or-later
 * Text Domain:       allin-pro
 * Domain Path:       /languages
 *
 * @package AllinPro
 */

defined( 'ABSPATH' ) || exit;

define( 'ALLIN_PRO_VERSION', '0.4.0' );
define( 'ALLIN_PRO_FILE', __FILE__ );
define( 'ALLIN_PRO_DIR', plugin_dir_path( __FILE__ ) );
define( 'ALLIN_PRO_URL', plugin_dir_url( __FILE__ ) );
define( 'ALLIN_PRO_OPTION', 'allin_pro_settings' );

/**
 * PSR-4-ish autoloader for the small class set this plugin owns.
 *
 * @param string $class Class name.
 */
spl_autoload_register(
	function ( $class ) {
		if ( 0 !== strpos( $class, 'AllinPro_' ) ) {
			return;
		}

		$file = 'class-' . strtolower( str_replace( '_', '-', substr( $class, 9 ) ) ) . '.php';

		foreach ( array( 'includes/', 'includes/adapters/', 'includes/modules/', 'includes/admin/', 'includes/payments/' ) as $dir ) {
			$path = ALLIN_PRO_DIR . $dir . $file;

			if ( is_readable( $path ) ) {
				require_once $path;
				return;
			}
		}
	}
);

require_once ALLIN_PRO_DIR . 'includes/functions.php';
require_once ALLIN_PRO_DIR . 'includes/class-settings.php';
require_once ALLIN_PRO_DIR . 'includes/class-adapters.php';
require_once ALLIN_PRO_DIR . 'includes/class-migrations.php';
require_once ALLIN_PRO_DIR . 'includes/class-modules.php';

/**
 * Boot the kernel.
 */
function allin_pro_boot() {
	load_plugin_textdomain( 'allin-pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

	AllinPro_Settings::instance();

	$adapters = AllinPro_Adapters::instance();

	// Sandbox implementations are always registered: they are what makes a site
	// without credentials usable, and the registry only falls back to them when
	// the real provider is unavailable.
	$adapters->register( 'sms', 'sandbox', function () { return new AllinPro_Sms_Sandbox(); } );

	foreach ( array( 'wechat', 'qq', 'weibo', 'github' ) as $channel ) {
		$adapters->register(
			'oauth',
			$channel,
			function () use ( $channel ) {
				return new AllinPro_Oauth_Sandbox( $channel );
			}
		);
	}

	/**
	 * Register real providers from a companion plugin or the site's own code.
	 *
	 * @param AllinPro_Adapters $adapters Registry.
	 */
	do_action( 'allin_pro_register_adapters', $adapters );

	AllinPro_Modules::instance()->boot();
	AllinPro_Payments::register();
	AllinPro_Balance::register();
	AllinPro_Recharge::register();
	AllinPro_Affiliate::register();
	AllinPro_Withdraw::register();
	AllinPro_Admin_Page::instance();
}

/**
 * Front-end assets for the login widgets. Tiny on purpose: the theme already
 * ships the design tokens these forms use.
 */
function allin_pro_assets() {
	if ( is_admin() ) {
		return;
	}

	wp_enqueue_style( 'allin-pro', ALLIN_PRO_URL . 'assets/allin.css', array(), ALLIN_PRO_VERSION );
	wp_enqueue_script( 'allin-pro', ALLIN_PRO_URL . 'assets/allin.js', array(), ALLIN_PRO_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'allin_pro_assets' );
add_action( 'plugins_loaded', 'allin_pro_boot', 5 );

/**
 * Activation: create tables, seed defaults, register rewrites, then flush once.
 */
function allin_pro_activate() {
	AllinPro_Settings::instance()->seed_defaults();
	AllinPro_Migrations::run();

	AllinPro_Modules::instance()->register_rewrites();
	flush_rewrite_rules();

	update_option( 'allin_pro_activated_at', gmdate( 'c' ) );
}
register_activation_hook( __FILE__, 'allin_pro_activate' );

/**
 * Deactivation: never destroy data — a site that switches the plugin off to
 * debug something must get its settings back when it switches it on again.
 */
function allin_pro_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'allin_pro_deactivate' );
